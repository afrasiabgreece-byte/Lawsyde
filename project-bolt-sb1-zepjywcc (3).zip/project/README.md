# Lawsyde - Legal Appointment Booking Platform

A modern, full-featured platform connecting clients with qualified lawyers worldwide. Built with React, TypeScript, Tailwind CSS, and Supabase.

## Features

### 🌟 Core Functionality
- **Landing Page** with intro video and animated backgrounds
- **Authentication** with email/password and OAuth (Google, Facebook)
- **Role-based Access** for clients and lawyers
- **Lawyer Discovery** with featured lawyer listings
- **Appointment Booking** with video and in-person options
- **Calendar Management** for both clients and lawyers
- **Video Calling** integration with Jitsi Meet
- **Real-time Communication** via phone and WhatsApp

### 🎨 Design Highlights
- Premium gradient animations and particle effects
- Responsive design for all device sizes
- Apple-level design aesthetics
- Smooth transitions and micro-interactions
- Modern glass morphism effects

### 🛠 Tech Stack
- **Frontend:** React 18, TypeScript, Tailwind CSS
- **Backend:** Supabase (Database, Auth, Real-time)
- **Routing:** React Router DOM
- **Video Calls:** Jitsi Meet
- **Icons:** Lucide React
- **Date Handling:** date-fns

## Quick Start

1. **Clone and Install**
   ```bash
   npm install
   ```

2. **Setup Supabase**
   - Create a Supabase project at https://supabase.com
   - Copy your project URL and anon key
   - Create a `.env` file with your Supabase credentials:
     ```
     VITE_SUPABASE_URL=your-supabase-project-url
     VITE_SUPABASE_ANON_KEY=your-supabase-anon-key
     ```

3. **Create Database Tables**
   ```sql
   -- Profiles table
   CREATE TABLE profiles (
     id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
     full_name TEXT NOT NULL,
     role TEXT NOT NULL CHECK (role IN ('client', 'lawyer')),
     email TEXT NOT NULL,
     phone TEXT,
     facebook_link TEXT,
     specialization TEXT,
     experience_years INTEGER,
     hourly_rate INTEGER,
     created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
   );

   -- Enable RLS
   ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

   -- Profiles policies
   CREATE POLICY "Public profiles are viewable by everyone" 
   ON profiles FOR SELECT 
   USING (true);

   CREATE POLICY "Users can insert their own profile" 
   ON profiles FOR INSERT 
   WITH CHECK (auth.uid() = id);

   CREATE POLICY "Users can update own profile" 
   ON profiles FOR UPDATE 
   USING (auth.uid() = id);

   -- Appointments table
   CREATE TABLE appointments (
     id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
     client_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
     lawyer_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
     type TEXT NOT NULL CHECK (type IN ('video', 'in-person')),
     scheduled_at TIMESTAMP WITH TIME ZONE NOT NULL,
     status TEXT NOT NULL DEFAULT 'confirmed' CHECK (status IN ('pending', 'confirmed', 'completed', 'cancelled')),
     description TEXT,
     created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
   );

   -- Enable RLS
   ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;

   -- Appointments policies
   CREATE POLICY "Users can view their own appointments" 
   ON appointments FOR SELECT 
   USING (auth.uid() = client_id OR auth.uid() = lawyer_id);

   CREATE POLICY "Clients can create appointments" 
   ON appointments FOR INSERT 
   WITH CHECK (auth.uid() = client_id);

   CREATE POLICY "Users can update their own appointments" 
   ON appointments FOR UPDATE 
   USING (auth.uid() = client_id OR auth.uid() = lawyer_id);
   ```

4. **Run Development Server**
   ```bash
   npm run dev
   ```

## Project Structure

```
src/
├── components/          # Reusable UI components
│   ├── BookingForm.tsx     # Appointment booking form
│   ├── CalendarView.tsx    # Calendar and appointment display
│   ├── ParticleBackground.tsx # Animated background effects
│   └── VideoPlayer.tsx     # Video intro player
├── pages/              # Main application pages
│   ├── LandingPage.tsx    # Landing page with intro
│   ├── AuthPage.tsx       # Authentication page
│   ├── RoleSelection.tsx  # Role selection page
│   └── Dashboard.tsx      # Main dashboard
├── lib/               # Utilities and configurations
│   └── supabase.ts       # Supabase client and types
├── App.tsx           # Main app component with routing
└── main.tsx         # Application entry point
```

## Key Features Explained

### Authentication Flow
1. Users land on the intro page with video
2. After video or manual skip, they see role selection
3. Authentication supports email/password and OAuth
4. Role selection determines dashboard experience

### Booking System
- Clients can browse featured lawyers
- Booking form supports both video and in-person meetings
- Real-time calendar updates
- Integrated video calling with Jitsi Meet

### Dashboard Experience
- **Clients:** Browse lawyers, manage appointments, join video calls
- **Lawyers:** View schedule, manage appointments, access client information

## Deployment

The application is ready for production deployment on platforms like:
- Vercel
- Netlify
- Railway
- Supabase hosting

Make sure to set environment variables in your deployment platform.

## Contributing

This is a production-ready application with room for additional features:
- Payment integration
- Rating and review system
- Advanced search and filtering
- Mobile app companion
- Document sharing
- AI-powered lawyer matching

## License

Built with ❤️ for connecting legal professionals with clients worldwide.