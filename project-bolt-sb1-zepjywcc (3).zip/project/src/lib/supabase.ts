import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

// Create a fallback client if environment variables are missing
const createSupabaseClient = () => {
  if (!supabaseUrl || !supabaseAnonKey) {
    console.warn('Missing Supabase environment variables - using demo mode');
    // Return a mock client for demo purposes
    return {
      auth: {
        getSession: () => Promise.resolve({ data: { session: null }, error: null }),
        getUser: () => Promise.resolve({ data: { user: null }, error: null }),
        signUp: () => Promise.resolve({ data: { user: null }, error: { message: 'Demo mode - Supabase not configured' } }),
        signInWithPassword: () => Promise.resolve({ data: { user: null }, error: { message: 'Demo mode - Supabase not configured' } }),
        signInWithOAuth: () => Promise.resolve({ data: { user: null }, error: { message: 'Demo mode - Supabase not configured' } }),
        signOut: () => Promise.resolve({ error: null }),
        onAuthStateChange: () => ({ data: { subscription: { unsubscribe: () => {} } } })
      },
      from: () => ({
        select: () => ({
          eq: () => ({
            single: () => Promise.resolve({ data: null, error: { message: 'Demo mode - Supabase not configured' } })
          })
        }),
        insert: () => Promise.resolve({ error: { message: 'Demo mode - Supabase not configured' } }),
        upsert: () => Promise.resolve({ error: { message: 'Demo mode - Supabase not configured' } })
      })
    } as any;
  }
  return createClient(supabaseUrl, supabaseAnonKey);
};

export const supabase = createSupabaseClient();

export type Profile = {
  id: string;
  full_name: string;
  role: 'client' | 'lawyer';
  email: string;
  phone?: string;
  facebook_link?: string;
  office_address?: string;
  created_at: string;
};

export type LawyerProfile = {
  id: string;
  user_id: string;
  lawyer_id?: string;
  bio?: string;
  years_experience?: number;
  hourly_rate?: number;
  languages?: string[];
  certifications?: string[];
  profile_completed?: boolean;
  created_at: string;
  updated_at: string;
};

export type Appointment = {
  id: string;
  user_id: string;
  lawyer_id?: string;
  appointment_type: 'video_call' | 'in_person';
  appointment_date: string;
  duration_minutes?: number;
  status?: 'pending' | 'confirmed' | 'cancelled' | 'completed';
  notes?: string;
  meeting_link?: string;
  location?: string;
  created_at: string;
  updated_at: string;
};

export type Booking = {
  id: string;
  client_id: string;
  lawyer_id: string;
  consultation_type: 'phone' | 'video' | 'in_person' | 'document_review';
  status: 'pending' | 'confirmed' | 'cancelled' | 'completed';
  preferred_date: string;
  preferred_time: string;
  message?: string;
  lawyer_response?: string;
  payment_status?: 'free' | 'pending' | 'paid' | 'failed';
  payment_id?: string;
  stripe_session_id?: string;
  created_at: string;
  updated_at: string;
};

// Featured lawyers data
export const featuredLawyers = [
  {
    id: '1',
    name: 'Nikos Paterakis',
    specialty: 'Immigration & Corporate Law',
    experience: 8,
    rating: 4.9,
    reviews: 127,
    availability: 'Available Now',
    aiScore: 98,
    phone: '+30 6947601994',
    email: 'nikos@lawsyde.com',
    facebook: 'https://www.facebook.com/nikos.paterakis97',
    image: 'https://images.pexels.com/photos/5668858/pexels-photo-5668858.jpeg?auto=compress&cs=tinysrgb&w=400',
    languages: ['Greek', 'English', 'German'],
    location: 'Athens, Greece',
    responseTime: '< 30 sec',
    casesResolved: 1247,
    aiEnhanced: true,
    freeConsultation: true
  },
  {
    id: '2',
    name: 'Ria Stavraka',
    specialty: 'Corporate & Immigration Law',
    experience: 6,
    rating: 4.8,
    reviews: 89,
    availability: 'Available Now',
    aiScore: 96,
    phone: '+30 6985799064',
    email: 'ria@lawsyde.com',
    facebook: 'https://www.facebook.com/ria.st.3',
    image: 'https://images.pexels.com/photos/5668473/pexels-photo-5668473.jpeg?auto=compress&cs=tinysrgb&w=400',
    languages: ['Greek', 'English'],
    location: 'Athens, Greece',
    responseTime: '< 15 sec',
    casesResolved: 892,
    aiEnhanced: true,
    freeConsultation: true
  },
  {
    id: '3',
    name: 'ADVALAW Firm',
    specialty: 'Immigration Law',
    experience: 12,
    rating: 4.9,
    reviews: 203,
    availability: 'Available Now',
    aiScore: 99,
    phone: '+30 6987377519',
    email: 'contact@advalaw.gr',
    facebook: 'https://www.facebook.com/advalaw.gr',
    image: 'https://images.pexels.com/photos/5668772/pexels-photo-5668772.jpeg?auto=compress&cs=tinysrgb&w=400',
    languages: ['Greek', 'English', 'French'],
    location: 'Athens, Greece',
    responseTime: '< 10 sec',
    casesResolved: 2156,
    aiEnhanced: true,
    freeConsultation: true
  },
  {
    id: '4',
    name: 'Expat Law',
    specialty: 'Immigration & Corporate Law',
    experience: 10,
    rating: 4.7,
    reviews: 156,
    availability: 'Available Now',
    aiScore: 94,
    phone: '+30 6945551914',
    email: 'info@expatlaw.gr',
    facebook: 'https://www.facebook.com/Xpatlaw',
    image: 'https://images.pexels.com/photos/5668473/pexels-photo-5668473.jpeg?auto=compress&cs=tinysrgb&w=400',
    languages: ['Greek', 'English', 'Spanish'],
    location: 'Athens, Greece',
    responseTime: '< 45 sec',
    casesResolved: 1089,
    aiEnhanced: true,
    freeConsultation: true
  },
  {
    id: '5',
    name: 'Oganov & Partners',
    specialty: 'Corporate & Immigration Law',
    experience: 15,
    rating: 4.9,
    reviews: 298,
    availability: 'Available Now',
    aiScore: 97,
    phone: '+30 6989825416',
    email: 'contact@oganov.gr',
    facebook: 'https://www.facebook.com/lawyerswithoutbordersgr',
    image: 'https://images.pexels.com/photos/5668858/pexels-photo-5668858.jpeg?auto=compress&cs=tinysrgb&w=400',
    languages: ['Greek', 'English', 'Russian'],
    location: 'Athens, Greece',
    responseTime: '< 20 sec',
    casesResolved: 3421,
    aiEnhanced: true,
    freeConsultation: true
  },
  {
    id: '6',
    name: 'Nefeli Makrynikola',
    specialty: 'Immigration & Corporate Law',
    experience: 7,
    rating: 4.8,
    reviews: 134,
    availability: 'Available Now',
    aiScore: 95,
    phone: '+30 6937288138',
    email: 'nefeli@lawsyde.com',
    facebook: 'https://www.facebook.com/profile.php?id=100064046242044',
    image: 'https://images.pexels.com/photos/5668473/pexels-photo-5668473.jpeg?auto=compress&cs=tinysrgb&w=400',
    languages: ['Greek', 'English'],
    location: 'Athens, Greece',
    responseTime: '< 1 min',
    casesResolved: 756,
    aiEnhanced: true,
    freeConsultation: true
  }
];