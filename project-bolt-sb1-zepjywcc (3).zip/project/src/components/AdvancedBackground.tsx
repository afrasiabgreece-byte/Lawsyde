import React from 'react';

const AdvancedBackground: React.FC = () => {
  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none" style={{ zIndex: -1 }}>
      {/* Base Professional Gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900">
        
        {/* Animated Legal Pattern Overlay */}
        <div className="absolute inset-0 opacity-10">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <defs>
              <pattern id="legalPattern" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
                <path d="M10,2 L18,10 L10,18 L2,10 Z" fill="none" stroke="currentColor" strokeWidth="0.5" className="text-blue-300" />
                <circle cx="10" cy="10" r="1" fill="currentColor" className="text-blue-400" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#legalPattern)" className="animate-pattern-drift" />
          </svg>
        </div>

        {/* Professional Geometric Shapes */}
        <div className="absolute inset-0">
          {[...Array(8)].map((_, i) => (
            <div
              key={`geo-${i}`}
              className="absolute border border-white/10 animate-geometric-float"
              style={{
                width: `${60 + i * 20}px`,
                height: `${60 + i * 20}px`,
                left: `${10 + i * 12}%`,
                top: `${15 + (i % 3) * 25}%`,
                borderRadius: i % 2 === 0 ? '50%' : '0%',
                animationDelay: `${i * 0.8}s`,
                animationDuration: `${8 + i * 2}s`,
                background: `linear-gradient(45deg, 
                  rgba(59, 130, 246, ${0.05 + i * 0.02}), 
                  rgba(147, 51, 234, ${0.03 + i * 0.01}))`,
              }}
            />
          ))}
        </div>

        {/* Advanced AI Neural Network */}
        <svg className="absolute inset-0 w-full h-full opacity-20">
          {[...Array(30)].map((_, i) => {
            const x1 = Math.random() * 100;
            const y1 = Math.random() * 100;
            const x2 = Math.random() * 100;
            const y2 = Math.random() * 100;
            
            return (
              <g key={`neural-${i}`}>
                <line
                  x1={`${x1}%`}
                  y1={`${y1}%`}
                  x2={`${x2}%`}
                  y2={`${y2}%`}
                  stroke="url(#neuralGradient)"
                  strokeWidth="1"
                  className="animate-neural-pulse"
                  style={{
                    animationDelay: `${i * 0.2}s`,
                    animationDuration: `${3 + Math.random() * 2}s`,
                  }}
                />
                <circle
                  cx={`${x1}%`}
                  cy={`${y1}%`}
                  r="2"
                  fill="url(#nodeGradient)"
                  className="animate-node-pulse"
                  style={{
                    animationDelay: `${i * 0.3}s`,
                  }}
                />
                <circle
                  cx={`${x2}%`}
                  cy={`${y2}%`}
                  r="1.5"
                  fill="url(#nodeGradient)"
                  className="animate-node-pulse"
                  style={{
                    animationDelay: `${i * 0.4}s`,
                  }}
                />
              </g>
            );
          })}
          <defs>
            <linearGradient id="neuralGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.6" />
              <stop offset="50%" stopColor="#8b5cf6" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.4" />
            </linearGradient>
            <radialGradient id="nodeGradient">
              <stop offset="0%" stopColor="#60a5fa" stopOpacity="1" />
              <stop offset="100%" stopColor="#3b82f6" stopOpacity="0.6" />
            </radialGradient>
          </defs>
        </svg>

        {/* Professional Data Visualization */}
        <div className="absolute inset-0 opacity-15">
          {[...Array(12)].map((_, i) => (
            <div
              key={`data-viz-${i}`}
              className="absolute animate-data-flow"
              style={{
                left: `${5 + i * 8}%`,
                top: '0%',
                width: '2px',
                height: '100%',
                background: `linear-gradient(to bottom, 
                  transparent, 
                  rgba(59, 130, 246, 0.6), 
                  rgba(147, 51, 234, 0.4), 
                  transparent)`,
                animationDelay: `${i * 0.5}s`,
                animationDuration: `${4 + Math.random() * 2}s`,
              }}
            />
          ))}
        </div>

        {/* Floating Legal Icons */}
        <div className="absolute inset-0">
          {[
            { icon: '⚖️', x: 15, y: 20 },
            { icon: '📋', x: 85, y: 25 },
            { icon: '🏛️', x: 10, y: 70 },
            { icon: '📊', x: 90, y: 75 },
            { icon: '🔍', x: 20, y: 85 },
            { icon: '💼', x: 80, y: 15 },
          ].map((item, i) => (
            <div
              key={`legal-icon-${i}`}
              className="absolute text-4xl opacity-20 animate-professional-float"
              style={{
                left: `${item.x}%`,
                top: `${item.y}%`,
                animationDelay: `${i * 1.2}s`,
                animationDuration: `${12 + i * 2}s`,
              }}
            >
              {item.icon}
            </div>
          ))}
        </div>

        {/* Advanced Particle System */}
        <div className="absolute inset-0">
          {[...Array(40)].map((_, i) => (
            <div
              key={`advanced-particle-${i}`}
              className="absolute rounded-full animate-advanced-float"
              style={{
                width: `${1 + Math.random() * 3}px`,
                height: `${1 + Math.random() * 3}px`,
                backgroundColor: 
                  i % 4 === 0 ? '#3b82f6' : // Professional Blue
                  i % 4 === 1 ? '#8b5cf6' : // Legal Purple  
                  i % 4 === 2 ? '#06b6d4' : // Tech Cyan
                  '#1e40af', // Deep Blue
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 15}s`,
                animationDuration: `${20 + Math.random() * 10}s`,
                opacity: 0.6,
                boxShadow: `0 0 ${4 + Math.random() * 6}px currentColor`,
              }}
            />
          ))}
        </div>

        {/* Professional Grid Overlay */}
        <div className="absolute inset-0 opacity-5">
          <div className="grid grid-cols-16 grid-rows-16 h-full w-full">
            {[...Array(256)].map((_, i) => (
              <div
                key={`pro-grid-${i}`}
                className="border border-blue-300 animate-grid-pulse"
                style={{
                  animationDelay: `${Math.random() * 8}s`,
                  animationDuration: `${6 + Math.random() * 4}s`,
                }}
              />
            ))}
          </div>
        </div>

        {/* Elegant Light Rays */}
        <div className="absolute inset-0">
          {[...Array(6)].map((_, i) => (
            <div
              key={`light-ray-${i}`}
              className="absolute animate-light-sweep"
              style={{
                width: '2px',
                height: '100%',
                background: `linear-gradient(to bottom, 
                  transparent, 
                  rgba(255, 255, 255, 0.1), 
                  rgba(59, 130, 246, 0.2), 
                  rgba(147, 51, 234, 0.1), 
                  transparent)`,
                left: `${10 + i * 15}%`,
                transformOrigin: 'top center',
                animationDelay: `${i * 2}s`,
                animationDuration: '12s',
              }}
            />
          ))}
        </div>

        {/* Professional Hexagon Pattern */}
        <div className="absolute inset-0 opacity-8">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <defs>
              <pattern id="hexPattern" x="0" y="0" width="10" height="8.66" patternUnits="userSpaceOnUse">
                <polygon 
                  points="5,0 9.33,2.5 9.33,7.5 5,10 0.67,7.5 0.67,2.5" 
                  fill="none" 
                  stroke="rgba(59, 130, 246, 0.1)" 
                  strokeWidth="0.2"
                  className="animate-hex-glow"
                />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#hexPattern)" />
          </svg>
        </div>
      </div>

      <style jsx>{`
        @keyframes patternDrift {
          0% { transform: translate(0, 0); }
          50% { transform: translate(-10px, -10px); }
          100% { transform: translate(0, 0); }
        }
        
        @keyframes geometricFloat {
          0%, 100% {
            transform: translateY(0px) rotate(0deg);
            opacity: 0.3;
          }
          25% {
            transform: translateY(-15px) rotate(90deg);
            opacity: 0.6;
          }
          50% {
            transform: translateY(-5px) rotate(180deg);
            opacity: 0.4;
          }
          75% {
            transform: translateY(-20px) rotate(270deg);
            opacity: 0.7;
          }
        }
        
        @keyframes neuralPulse {
          0%, 100% {
            opacity: 0.3;
            stroke-width: 1;
          }
          50% {
            opacity: 0.8;
            stroke-width: 2;
          }
        }
        
        @keyframes nodePulse {
          0%, 100% {
            transform: scale(1);
            opacity: 0.6;
          }
          50% {
            transform: scale(1.5);
            opacity: 1;
          }
        }
        
        @keyframes dataFlow {
          0% {
            transform: translateY(-100%);
            opacity: 0;
          }
          10%, 90% {
            opacity: 1;
          }
          100% {
            transform: translateY(100vh);
            opacity: 0;
          }
        }
        
        @keyframes professionalFloat {
          0%, 100% {
            transform: translateY(0px) translateX(0px) scale(1);
            opacity: 0.2;
          }
          25% {
            transform: translateY(-20px) translateX(10px) scale(1.1);
            opacity: 0.4;
          }
          50% {
            transform: translateY(-10px) translateX(-15px) scale(0.9);
            opacity: 0.3;
          }
          75% {
            transform: translateY(-25px) translateX(5px) scale(1.05);
            opacity: 0.35;
          }
        }
        
        @keyframes advancedFloat {
          0%, 100% {
            transform: translateY(0px) translateX(0px) rotate(0deg);
            opacity: 0.6;
          }
          33% {
            transform: translateY(-15px) translateX(8px) rotate(120deg);
            opacity: 0.8;
          }
          66% {
            transform: translateY(10px) translateX(-12px) rotate(240deg);
            opacity: 0.4;
          }
        }
        
        @keyframes gridPulse {
          0%, 100% {
            border-color: rgba(59, 130, 246, 0.1);
          }
          50% {
            border-color: rgba(147, 51, 234, 0.3);
          }
        }
        
        @keyframes lightSweep {
          0% {
            transform: translateX(-100%) skewX(-15deg);
            opacity: 0;
          }
          50% {
            opacity: 1;
          }
          100% {
            transform: translateX(100vw) skewX(-15deg);
            opacity: 0;
          }
        }
        
        @keyframes hexGlow {
          0%, 100% {
            stroke: rgba(59, 130, 246, 0.1);
          }
          50% {
            stroke: rgba(147, 51, 234, 0.2);
          }
        }
        
        .animate-pattern-drift {
          animation: patternDrift 20s ease-in-out infinite;
        }
        
        .animate-geometric-float {
          animation: geometricFloat 15s ease-in-out infinite;
        }
        
        .animate-neural-pulse {
          animation: neuralPulse 3s ease-in-out infinite;
        }
        
        .animate-node-pulse {
          animation: nodePulse 2s ease-in-out infinite;
        }
        
        .animate-data-flow {
          animation: dataFlow 6s linear infinite;
        }
        
        .animate-professional-float {
          animation: professionalFloat 18s ease-in-out infinite;
        }
        
        .animate-advanced-float {
          animation: advancedFloat 25s ease-in-out infinite;
        }
        
        .animate-grid-pulse {
          animation: gridPulse 8s ease-in-out infinite;
        }
        
        .animate-light-sweep {
          animation: lightSweep 12s ease-in-out infinite;
        }
        
        .animate-hex-glow {
          animation: hexGlow 6s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};

export default AdvancedBackground;
