import React from 'react';

const ModernBackground: React.FC = () => {
  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none" style={{ zIndex: -1 }}>
      {/* Professional Deep Navy to Emerald Gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-emerald-900 to-teal-900">
        
        {/* Innovative Grid System */}
        <div className="absolute inset-0 opacity-20">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <defs>
              <pattern id="modernGrid" x="0" y="0" width="10" height="10" patternUnits="userSpaceOnUse">
                <path d="M 10 0 L 0 0 0 10" fill="none" stroke="currentColor" strokeWidth="0.5" className="text-emerald-300" />
              </pattern>
              <linearGradient id="modernGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#10b981" stopOpacity="0.12" />
                <stop offset="50%" stopColor="#0d9488" stopOpacity="0.18" />
                <stop offset="100%" stopColor="#0891b2" stopOpacity="0.10" />
              </linearGradient>
            </defs>
            <rect width="100%" height="100%" fill="url(#modernGrid)" />
            <rect width="100%" height="100%" fill="url(#modernGradient)" className="animate-gradient-shift" />
          </svg>
        </div>

        {/* Professional Floating Elements */}
        <div className="absolute inset-0">
          {[...Array(12)].map((_, i) => (
            <div
              key={`modern-element-${i}`}
              className="absolute animate-professional-drift"
              style={{
                left: `${10 + i * 8}%`,
                top: `${15 + (i % 4) * 20}%`,
                animationDelay: `${i * 1.5}s`,
                animationDuration: `${20 + i * 3}s`,
              }}
            >
              <div
                className="bg-gradient-to-br from-blue-400/20 to-purple-400/10 backdrop-blur-sm border border-white/10 rounded-lg"
                style={{
                  width: `${40 + Math.random() * 60}px`,
                  height: `${30 + Math.random() * 40}px`,
                }}
              />
            </div>
          ))}
        </div>

        {/* Innovative Connection Lines */}
        <svg className="absolute inset-0 w-full h-full opacity-15">
          {[...Array(20)].map((_, i) => {
            const x1 = Math.random() * 100;
            const y1 = Math.random() * 100;
            const x2 = Math.random() * 100;
            const y2 = Math.random() * 100;
            
            return (
              <line
                key={`connection-${i}`}
                x1={`${x1}%`}
                y1={`${y1}%`}
                x2={`${x2}%`}
                y2={`${y2}%`}
                stroke="url(#connectionGradient)"
                strokeWidth="1"
                className="animate-connection-pulse"
                style={{
                  animationDelay: `${i * 0.5}s`,
                  animationDuration: `${4 + Math.random() * 3}s`,
                }}
              />
            );
          })}
          <defs>
            <linearGradient id="connectionGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#10b981" stopOpacity="0.4" />
              <stop offset="50%" stopColor="#0d9488" stopOpacity="0.6" />
              <stop offset="100%" stopColor="#0891b2" stopOpacity="0.2" />
            </linearGradient>
          </defs>
        </svg>

        {/* Modern Geometric Shapes */}
        <div className="absolute inset-0">
          {[...Array(8)].map((_, i) => (
            <div
              key={`geo-shape-${i}`}
              className="absolute animate-geometric-rotation"
              style={{
                left: `${15 + i * 12}%`,
                top: `${20 + (i % 3) * 25}%`,
                animationDelay: `${i * 2}s`,
                animationDuration: `${25 + i * 5}s`,
              }}
            >
              <div
                className={`border-2 border-blue-300/30 ${
                  i % 3 === 0 ? 'rounded-full' : 
                  i % 3 === 1 ? 'rounded-lg rotate-45' : 
                  'rounded-none'
                }`}
                style={{
                  width: `${50 + i * 10}px`,
                  height: `${50 + i * 10}px`,
                  background: `linear-gradient(45deg, 
                    rgba(16, 185, 129, ${0.08 + i * 0.02}), 
                    rgba(13, 148, 136, ${0.05 + i * 0.01}))`,
                }}
              />
            </div>
          ))}
        </div>

        {/* Professional Data Visualization */}
        <div className="absolute inset-0 opacity-10">
          {[...Array(15)].map((_, i) => (
            <div
              key={`data-bar-${i}`}
              className="absolute animate-data-visualization"
              style={{
                left: `${5 + i * 6}%`,
                bottom: '10%',
                width: '3px',
                height: `${20 + Math.random() * 60}%`,
                background: `linear-gradient(to top, 
                  rgba(16, 185, 129, 0.6), 
                  rgba(13, 148, 136, 0.4), 
                  transparent)`,
                animationDelay: `${i * 0.3}s`,
                animationDuration: `${3 + Math.random() * 2}s`,
              }}
            />
          ))}
        </div>

        {/* Innovative Particle Network */}
        <div className="absolute inset-0">
          {[...Array(30)].map((_, i) => (
            <div
              key={`network-particle-${i}`}
              className="absolute rounded-full animate-network-float"
              style={{
                width: `${2 + Math.random() * 4}px`,
                height: `${2 + Math.random() * 4}px`,
                backgroundColor: 
                  i % 4 === 0 ? '#10b981' : 
                  i % 4 === 1 ? '#0d9488' : 
                  i % 4 === 2 ? '#0891b2' : 
                  '#065f46',
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 10}s`,
                animationDuration: `${15 + Math.random() * 10}s`,
                opacity: 0.6,
                boxShadow: `0 0 ${4 + Math.random() * 6}px currentColor`,
              }}
            />
          ))}
        </div>

        {/* Modern Wave Patterns */}
        <div className="absolute inset-0 opacity-20">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <path
              d="M0,50 Q25,30 50,50 T100,50 L100,100 L0,100 Z"
              fill="url(#waveGradient)"
              className="animate-wave-flow"
            />
            <path
              d="M0,60 Q25,40 50,60 T100,60 L100,100 L0,100 Z"
              fill="url(#waveGradient2)"
              className="animate-wave-flow-reverse"
            />
            <defs>
              <linearGradient id="waveGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#10b981" stopOpacity="0.1" />
                <stop offset="100%" stopColor="#0d9488" stopOpacity="0.05" />
              </linearGradient>
              <linearGradient id="waveGradient2" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#0891b2" stopOpacity="0.08" />
                <stop offset="100%" stopColor="#10b981" stopOpacity="0.03" />
              </linearGradient>
            </defs>
          </svg>
        </div>

        {/* Professional Light Beams */}
        <div className="absolute inset-0">
          {[...Array(5)].map((_, i) => (
            <div
              key={`light-beam-${i}`}
              className="absolute animate-light-beam"
              style={{
                width: '1px',
                height: '100%',
                background: `linear-gradient(to bottom, 
                  transparent, 
                  rgba(255, 255, 255, 0.08), 
                  rgba(16, 185, 129, 0.15), 
                  rgba(13, 148, 136, 0.08), 
                  transparent)`,
                left: `${20 + i * 15}%`,
                transformOrigin: 'top center',
                animationDelay: `${i * 3}s`,
                animationDuration: '15s',
              }}
            />
          ))}
        </div>

        {/* Innovative Hexagonal Tech Pattern */}
        <div className="absolute inset-0 opacity-8">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <defs>
              <pattern id="hexTechPattern" x="0" y="0" width="8" height="7" patternUnits="userSpaceOnUse">
                <polygon 
                  points="4,0 7,2 7,5 4,7 1,5 1,2" 
                  fill="none" 
                  stroke="rgba(16, 185, 129, 0.15)" 
                  strokeWidth="0.3"
                  className="animate-hex-pulse"
                />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#hexTechPattern)" />
          </svg>
        </div>

        {/* Professional Ambient Orbs */}
        <div className="absolute inset-0">
          {[
            { x: 25, y: 20, color: 'emerald', size: 300 },
            { x: 75, y: 70, color: 'teal', size: 250 },
            { x: 50, y: 50, color: 'cyan', size: 200 },
          ].map((orb, i) => (
            <div
              key={`ambient-orb-${i}`}
              className="absolute rounded-full animate-ambient-pulse"
              style={{
                left: `${orb.x}%`,
                top: `${orb.y}%`,
                width: `${orb.size}px`,
                height: `${orb.size}px`,
                background: `radial-gradient(circle, 
                  ${orb.color === 'emerald' ? 'rgba(16, 185, 129, 0.08)' : 
                    orb.color === 'teal' ? 'rgba(13, 148, 136, 0.06)' : 
                    'rgba(8, 145, 178, 0.05)'} 0%, 
                  transparent 70%)`,
                animationDelay: `${i * 5}s`,
                animationDuration: `${20 + i * 5}s`,
              }}
            />
          ))}
        </div>
      </div>

      <style jsx>{`
        @keyframes gradientShift {
          0%, 100% {
            transform: translateX(0) translateY(0);
          }
          25% {
            transform: translateX(-2%) translateY(-1%);
          }
          50% {
            transform: translateX(2%) translateY(-2%);
          }
          75% {
            transform: translateX(-1%) translateY(1%);
          }
        }
        
        @keyframes professionalDrift {
          0%, 100% {
            transform: translateY(0px) translateX(0px) rotate(0deg);
            opacity: 0.3;
          }
          25% {
            transform: translateY(-20px) translateX(10px) rotate(2deg);
            opacity: 0.6;
          }
          50% {
            transform: translateY(-10px) translateX(-15px) rotate(-1deg);
            opacity: 0.4;
          }
          75% {
            transform: translateY(-25px) translateX(5px) rotate(1deg);
            opacity: 0.7;
          }
        }
        
        @keyframes connectionPulse {
          0%, 100% {
            opacity: 0.2;
            stroke-width: 1;
          }
          50% {
            opacity: 0.6;
            stroke-width: 2;
          }
        }
        
        @keyframes geometricRotation {
          0% {
            transform: rotate(0deg) scale(1);
            opacity: 0.3;
          }
          50% {
            transform: rotate(180deg) scale(1.1);
            opacity: 0.6;
          }
          100% {
            transform: rotate(360deg) scale(1);
            opacity: 0.3;
          }
        }
        
        @keyframes dataVisualization {
          0%, 100% {
            height: 20%;
            opacity: 0.4;
          }
          50% {
            height: 80%;
            opacity: 0.8;
          }
        }
        
        @keyframes networkFloat {
          0%, 100% {
            transform: translateY(0px) translateX(0px);
            opacity: 0.6;
          }
          25% {
            transform: translateY(-30px) translateX(20px);
            opacity: 0.8;
          }
          50% {
            transform: translateY(-15px) translateX(-25px);
            opacity: 0.4;
          }
          75% {
            transform: translateY(-35px) translateX(15px);
            opacity: 0.9;
          }
        }
        
        @keyframes waveFlow {
          0% {
            transform: translateX(-100%);
          }
          100% {
            transform: translateX(100%);
          }
        }
        
        @keyframes waveFlowReverse {
          0% {
            transform: translateX(100%);
          }
          100% {
            transform: translateX(-100%);
          }
        }
        
        @keyframes lightBeam {
          0% {
            transform: translateX(-50%) skewX(-10deg);
            opacity: 0;
          }
          50% {
            opacity: 1;
          }
          100% {
            transform: translateX(150%) skewX(-10deg);
            opacity: 0;
          }
        }
        
        @keyframes hexPulse {
          0%, 100% {
            stroke: rgba(16, 185, 129, 0.1);
            stroke-width: 0.3;
          }
          50% {
            stroke: rgba(13, 148, 136, 0.2);
            stroke-width: 0.6;
          }
        }
        
        @keyframes ambientPulse {
          0%, 100% {
            opacity: 0.05;
            transform: scale(1);
          }
          50% {
            opacity: 0.15;
            transform: scale(1.2);
          }
        }
        
        .animate-gradient-shift {
          animation: gradientShift 30s ease-in-out infinite;
        }
        
        .animate-professional-drift {
          animation: professionalDrift 20s ease-in-out infinite;
        }
        
        .animate-connection-pulse {
          animation: connectionPulse 4s ease-in-out infinite;
        }
        
        .animate-geometric-rotation {
          animation: geometricRotation 30s linear infinite;
        }
        
        .animate-data-visualization {
          animation: dataVisualization 5s ease-in-out infinite;
        }
        
        .animate-network-float {
          animation: networkFloat 25s ease-in-out infinite;
        }
        
        .animate-wave-flow {
          animation: waveFlow 20s ease-in-out infinite;
        }
        
        .animate-wave-flow-reverse {
          animation: waveFlowReverse 25s ease-in-out infinite;
        }
        
        .animate-light-beam {
          animation: lightBeam 18s ease-in-out infinite;
        }
        
        .animate-hex-pulse {
          animation: hexPulse 8s ease-in-out infinite;
        }
        
        .animate-ambient-pulse {
          animation: ambientPulse 15s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};

export default ModernBackground;