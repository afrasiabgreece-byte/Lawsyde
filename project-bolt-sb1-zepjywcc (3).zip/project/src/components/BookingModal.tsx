import React, { useState } from 'react';
import { supabase } from '../lib/supabase';
import { X, Calendar, Clock, Video, MapPin, Phone, MessageCircle, User, FileText, CreditCard, Check, AlertCircle, CheckCircle, ArrowLeft } from 'lucide-react';

interface BookingModalProps {
  lawyer: any;
  isOpen: boolean;
  onClose: () => void;
  userProfile: any;
}

const BookingModal: React.FC<BookingModalProps> = ({ lawyer, isOpen, onClose, userProfile }) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    consultationType: '',
    preferredDate: '',
    preferredTime: '',
    message: '',
    clientName: userProfile?.full_name || '',
    clientEmail: userProfile?.email || '',
    clientPhone: '',
    agreedRate: '',
    paymentMethod: 'cash'
  });
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmitBooking = async () => {
    setLoading(true);
    try {
      const { error } = await supabase.from('bookings').insert({
        client_id: userProfile?.id,
        lawyer_id: lawyer.id,
        consultation_type: formData.consultationType,
        status: 'pending',
        preferred_date: formData.preferredDate,
        preferred_time: formData.preferredTime,
        message: formData.message,
        payment_status: formData.consultationType === 'phone' ? 'free' : 'pending'
      });

      if (error) throw error;
      
      alert('🎉 Booking request sent! The lawyer will contact you to confirm details and pricing.');
      onClose();
      setStep(1);
      setFormData({
        consultationType: '',
        preferredDate: '',
        preferredTime: '',
        message: '',
        clientName: userProfile?.full_name || '',
        clientEmail: userProfile?.email || '',
        clientPhone: '',
        agreedRate: '',
        paymentMethod: 'cash'
      });
    } catch (error: any) {
      alert('Error: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const timeSlots = [
    '09:00', '09:30', '10:00', '10:30', '11:00', '11:30',
    '12:00', '12:30', '13:00', '13:30', '14:00', '14:30',
    '15:00', '15:30', '16:00', '16:30', '17:00', '17:30'
  ];

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b">
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors duration-200 mr-4"
            title="Back"
          >
            <ArrowLeft className="w-5 h-5 text-gray-500" />
          </button>
          <div className="flex items-center">
            <img
              src={lawyer.image}
              alt={lawyer.name}
              className="w-12 h-12 rounded-full object-cover mr-4"
            />
            <div>
              <h2 className="text-xl font-bold text-gray-800">{lawyer.name}</h2>
              <p className="text-gray-600">{lawyer.specialty}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors duration-200"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        {/* Step Indicator */}
        <div className="px-6 py-4 bg-gray-50">
          <div className="flex items-center space-x-4">
            <div className={`flex items-center ${step >= 1 ? 'text-blue-600' : 'text-gray-400'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 1 ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}>
                1
              </div>
              <span className="ml-2 font-medium">Service Type</span>
            </div>
            <div className={`w-8 h-0.5 ${step >= 2 ? 'bg-blue-600' : 'bg-gray-200'}`}></div>
            <div className={`flex items-center ${step >= 2 ? 'text-blue-600' : 'text-gray-400'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 2 ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}>
                2
              </div>
              <span className="ml-2 font-medium">Schedule</span>
            </div>
            <div className={`w-8 h-0.5 ${step >= 3 ? 'bg-blue-600' : 'bg-gray-200'}`}></div>
            <div className={`flex items-center ${step >= 3 ? 'text-blue-600' : 'text-gray-400'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 3 ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}>
                3
              </div>
              <span className="ml-2 font-medium">Details</span>
            </div>
          </div>
        </div>

        {/* Step Content */}
        <div className="p-6">
          {step === 1 && (
            <div className="space-y-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Choose Consultation Type</h3>
              
              {/* Free Options */}
              <div className="space-y-3">
                <h4 className="text-md font-medium text-green-600 flex items-center">
                  <Check className="w-5 h-5 mr-2" />
                  Free Consultations (Instant Access)
                </h4>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <button
                    onClick={() => window.open(`tel:${lawyer.phone}`, '_self')}
                    className="p-6 border-3 border-green-300 rounded-xl hover:border-green-400 bg-gradient-to-r from-green-50 to-emerald-50 hover:from-green-100 hover:to-emerald-100 transition-all duration-300 group shadow-xl hover:shadow-green-500/40 transform hover:scale-115 relative overflow-hidden"
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-green-200/20 to-emerald-200/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    <div className="relative z-10">
                    <div className="text-4xl mx-auto mb-3 group-hover:scale-125 transition-transform duration-300">📞</div>
                    <div className="text-sm font-bold text-gray-800">Phone Call</div>
                    <div className="text-xs text-green-600 font-bold bg-green-100 px-2 py-1 rounded-full">FREE</div>
                    </div>
                  </button>
                  
                  <button
                    onClick={() => window.open(`https://wa.me/${lawyer.phone.replace(/\D/g, '')}`, '_blank')}
                    className="p-6 border-3 border-green-300 rounded-xl hover:border-green-400 bg-gradient-to-r from-green-50 to-emerald-50 hover:from-green-100 hover:to-emerald-100 transition-all duration-300 group shadow-xl hover:shadow-green-500/40 transform hover:scale-115 relative overflow-hidden"
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-green-200/20 to-emerald-200/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    <div className="relative z-10">
                    <div className="text-4xl mx-auto mb-3 group-hover:scale-125 transition-transform duration-300">💬</div>
                    <div className="text-sm font-bold text-gray-800">WhatsApp</div>
                    <div className="text-xs text-green-600 font-bold bg-green-100 px-2 py-1 rounded-full">FREE</div>
                    </div>
                  </button>
                  
                  <button
                    onClick={() => window.open(lawyer.facebook, '_blank')}
                    className="p-6 border-3 border-green-300 rounded-xl hover:border-green-400 bg-gradient-to-r from-green-50 to-emerald-50 hover:from-green-100 hover:to-emerald-100 transition-all duration-300 group shadow-xl hover:shadow-green-500/40 transform hover:scale-115 relative overflow-hidden"
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-green-200/20 to-emerald-200/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    <div className="relative z-10">
                    <div className="text-4xl mx-auto mb-3 group-hover:scale-125 transition-transform duration-300">📘</div>
                    <div className="text-sm font-bold text-gray-800">Facebook</div>
                    <div className="text-xs text-green-600 font-bold bg-green-100 px-2 py-1 rounded-full">FREE</div>
                    </div>
                  </button>
                </div>
              </div>

              {/* Premium Options */}
              <div className="space-y-3">
                <h4 className="text-md font-medium text-blue-600 flex items-center">
                  <Calendar className="w-5 h-5 mr-2" />
                  Scheduled Meetings (Book in Advance)
                </h4>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <button
                    onClick={() => {
                      handleInputChange('consultationType', 'video');
                      setStep(2);
                    }}
                    className={`p-6 border-3 rounded-xl transition-all duration-300 group shadow-lg hover:shadow-blue-500/30 transform hover:scale-110 relative overflow-hidden ${
                      formData.consultationType === 'video'
                        ? 'border-blue-500 bg-gradient-to-r from-blue-50 to-blue-100'
                        : 'border-gray-200 hover:border-blue-400 hover:bg-gradient-to-r hover:from-blue-50 hover:to-blue-100'
                    }`}
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-blue-200/20 to-blue-300/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    <div className="relative z-10 text-center">
                    <div className="text-3xl mx-auto mb-2 group-hover:scale-110 transition-transform duration-300">📹</div>
                    <div className="text-sm font-bold text-gray-800">Video Call</div>
                    <div className="text-xs text-blue-600">Schedule with lawyer</div>
                    </div>
                  </button>
                  
                  <button
                    onClick={() => {
                      handleInputChange('consultationType', 'in_person');
                      setStep(2);
                    }}
                    className={`p-6 border-3 rounded-xl transition-all duration-300 group shadow-lg hover:shadow-blue-500/30 transform hover:scale-110 relative overflow-hidden ${
                      formData.consultationType === 'in_person'
                        ? 'border-blue-500 bg-gradient-to-r from-blue-50 to-blue-100'
                        : 'border-gray-200 hover:border-blue-400 hover:bg-gradient-to-r hover:from-blue-50 hover:to-blue-100'
                    }`}
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-blue-200/20 to-blue-300/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    <div className="relative z-10 text-center">
                    <div className="text-3xl mx-auto mb-2 group-hover:scale-110 transition-transform duration-300">🏢</div>
                    <div className="text-sm font-bold text-gray-800">On-site Visit</div>
                    <div className="text-xs text-blue-600">Schedule with lawyer</div>
                    </div>
                  </button>
                </div>
              </div>

              <div className="bg-green-50 border border-green-200 rounded-xl p-4">
                <div className="flex items-start">
                  <CheckCircle className="w-5 h-5 text-green-600 mr-3 mt-0.5" />
                  <div className="text-sm text-green-800">
                    <p className="font-medium mb-1">All Services Are Free:</p>
                    <p>📹 Video calls and 🏢 on-site visits are completely free. Booking helps lawyers organize their schedule and ensures dedicated time for your consultation.</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-800">Schedule Your {formData.consultationType === 'video' ? 'Video Call' : 'On-site Visit'}</h3>
                <button
                  onClick={() => setStep(1)}
                  className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                >
                  ← Back
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <Calendar className="w-4 h-4 inline mr-1" />
                    Preferred Date
                  </label>
                  <input
                    type="date"
                    value={formData.preferredDate}
                    onChange={(e) => handleInputChange('preferredDate', e.target.value)}
                    min={new Date().toISOString().split('T')[0]}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <Clock className="w-4 h-4 inline mr-1" />
                    Preferred Time
                  </label>
                  <select
                    value={formData.preferredTime}
                    onChange={(e) => handleInputChange('preferredTime', e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">Select time</option>
                    {timeSlots.map((time) => (
                      <option key={time} value={time}>{time}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <FileText className="w-4 h-4 inline mr-1" />
                  Describe Your Legal Matter
                </label>
                <textarea
                  value={formData.message}
                  onChange={(e) => handleInputChange('message', e.target.value)}
                  placeholder="Please describe your legal issue so the lawyer can prepare and provide accurate pricing..."
                  rows={4}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                />
              </div>

              <div className="flex justify-end space-x-3">
                <button
                  onClick={() => setStep(1)}
                  className="px-6 py-3 border-2 border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition-all duration-300 transform hover:scale-105 font-medium flex items-center shadow-lg hover:shadow-gray-500/30"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back
                </button>
                <button
                  onClick={() => setStep(3)}
                  disabled={!formData.preferredDate || !formData.preferredTime || !formData.message}
                  className="px-6 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Continue
                </button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-800">Contact Information & Pricing</h3>
                <button
                  onClick={() => setStep(2)}
                  className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                >
                  ← Back
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Full Name
                  </label>
                  <input
                    type="text"
                    value={formData.clientName}
                    onChange={(e) => handleInputChange('clientName', e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    value={formData.clientPhone}
                    onChange={(e) => handleInputChange('clientPhone', e.target.value)}
                    placeholder="+30 123 456 7890"
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Email Address
                </label>
                <input
                  type="email"
                  value={formData.clientEmail}
                  onChange={(e) => handleInputChange('clientEmail', e.target.value)}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              {/* Pricing Discussion */}
              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4">
                <div className="flex items-start">
                  <CheckCircle className="w-5 h-5 text-emerald-600 mr-3 mt-0.5" />
                  <div className="text-sm text-emerald-800">
                    <p className="font-medium mb-2">Free Platform Access:</p>
                    <p>Platform access is free. The lawyer will contact you to confirm the appointment details and discuss their service rates.</p>
                  </div>
                </div>
              </div>

              {/* Booking Summary */}
              <div className="bg-gray-50 rounded-xl p-4">
                <h4 className="font-medium text-gray-800 mb-3">Booking Summary</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Lawyer:</span>
                    <span className="font-medium">{lawyer.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Service:</span>
                    <span className="font-medium capitalize">{formData.consultationType.replace('_', ' ')}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Date:</span>
                    <span className="font-medium">{formData.preferredDate}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Time:</span>
                    <span className="font-medium">{formData.preferredTime}</span>
                  </div>
                </div>
              </div>

              <div className="flex justify-end space-x-3">
                <button
                  onClick={() => setStep(2)}
                  className="px-6 py-3 border-2 border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition-all duration-300 transform hover:scale-105 font-medium flex items-center shadow-lg hover:shadow-gray-500/30"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back
                </button>
                <button
                  onClick={handleSubmitBooking}
                  disabled={loading || !formData.clientName || !formData.clientPhone || !formData.clientEmail}
                  className="px-8 py-4 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl font-bold text-lg transition-all duration-300 transform hover:scale-110 disabled:opacity-50 disabled:cursor-not-allowed flex items-center shadow-xl hover:shadow-emerald-500/60 border-2 border-emerald-300/30 hover:border-emerald-200 relative overflow-hidden"
                >
                  <span className="relative z-10 flex items-center">
                    {loading ? (
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                    ) : (
                      <Check className="w-5 h-5 mr-2" />
                    )}
                    {loading ? 'Sending...' : 'Send Booking Request'}
                  </span>
                  <div className="absolute inset-0 bg-gradient-to-r from-emerald-400 to-teal-400 opacity-0 hover:opacity-30 transition-opacity duration-300"></div>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BookingModal;