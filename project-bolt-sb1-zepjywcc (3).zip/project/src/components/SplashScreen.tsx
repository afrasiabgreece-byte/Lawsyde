import React, { useEffect, useState } from 'react';
import { Scale, Sparkles, Zap, Brain, Bot, Cpu, Network, Eye, Lightbulb, Shield, Globe, Users, Target, CheckCircle, Award } from 'lucide-react';
import AdvancedBackground from './AdvancedBackground';

interface SplashScreenProps {
  onComplete: () => void;
}

const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
  const [isVisible, setIsVisible] = useState(true);
  const [animationPhase, setAnimationPhase] = useState(0);
  const [aiText, setAiText] = useState('');
  const [logoScale, setLogoScale] = useState(1);
  const [particleCount, setParticleCount] = useState(0);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  // Professional lawyer-client connection images
  const backgroundImages = [
    'https://images.pexels.com/photos/5668858/pexels-photo-5668858.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    'https://images.pexels.com/photos/5668473/pexels-photo-5668473.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    'https://images.pexels.com/photos/5668772/pexels-photo-5668772.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    'https://images.pexels.com/photos/7876050/pexels-photo-7876050.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    'https://images.pexels.com/photos/8112198/pexels-photo-8112198.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    'https://images.pexels.com/photos/5668869/pexels-photo-5668869.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080'
  ];

  const aiMessages = [
    'Initializing AI legal network...',
    'Connecting Athens lawyers...',
    'Analyzing immigration & corporate law...',
    'Optimizing lawyer-client matching...',
    'Platform ready for connections!'
  ];

  useEffect(() => {
    // Background image rotation every 4 seconds
    const imageInterval = setInterval(() => {
      setCurrentImageIndex(prev => (prev + 1) % backgroundImages.length);
    }, 4000);

    // AI text animation
    let messageIndex = 0;
    const textInterval = setInterval(() => {
      if (messageIndex < aiMessages.length) {
        setAiText(aiMessages[messageIndex]);
        messageIndex++;
      }
    }, 800);

    // Logo scaling animation
    const logoInterval = setInterval(() => {
      setLogoScale(prev => prev === 1 ? 1.1 : 1);
    }, 2000);

    // Particle animation
    const particleInterval = setInterval(() => {
      setParticleCount(prev => (prev + 1) % 50);
    }, 100);

    // Animation phases
    const phases = [
      { delay: 0, phase: 0 },
      { delay: 800, phase: 1 },
      { delay: 1600, phase: 2 },
      { delay: 2400, phase: 3 },
      { delay: 3200, phase: 4 },
      { delay: 4000, phase: 5 },
    ];

    phases.forEach(({ delay, phase }) => {
      setTimeout(() => setAnimationPhase(phase), delay);
    });

    const timer = setTimeout(() => {
      setIsVisible(false);
      setTimeout(onComplete, 800);
    }, 6000);

    return () => {
      clearTimeout(timer);
      clearInterval(imageInterval);
      clearInterval(textInterval);
      clearInterval(logoInterval);
      clearInterval(particleInterval);
    };
  }, [onComplete]);

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center transition-opacity duration-500 ${
        isVisible ? 'opacity-100' : 'opacity-0'
      }`}
    >
      {/* Dynamic Background Images */}
      <div className="absolute inset-0">
        {backgroundImages.map((image, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-1000 ${
              index === currentImageIndex ? 'opacity-100' : 'opacity-0'
            }`}
            style={{
              backgroundImage: `url(${image})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
              backgroundRepeat: 'no-repeat',
            }}
          >
            {/* Dark overlay for text readability */}
            <div className="absolute inset-0 bg-gradient-to-br from-slate-900/80 via-blue-900/70 to-indigo-900/80"></div>
          </div>
        ))}
      </div>

      {/* Enhanced Animated Overlay */}
      <div className="absolute inset-0 pointer-events-none">
        <AdvancedBackground />
      </div>

      {/* Main Content */}
      <div className="relative z-10 text-center text-white px-6">
        {/* Enhanced Logo with Multiple Effects */}
        <div className="mb-16 relative">
          {/* Outer Rotating Ring */}
          <div className="absolute inset-0 animate-spin-slow">
            <div className="w-40 h-40 border-2 border-dashed border-emerald-400 rounded-full mx-auto opacity-60"></div>
          </div>
          
          {/* Middle Pulse Ring with Enhanced Effect */}
          <div className="absolute inset-0 animate-ping">
            <div className="w-32 h-32 border-4 border-teal-400 rounded-full mx-auto opacity-50"></div>
          </div>
          
          {/* Main Logo with Dynamic Scaling */}
          <div 
            className="relative z-10 w-32 h-32 mx-auto bg-gradient-to-br from-white to-emerald-200 rounded-full flex items-center justify-center animate-enhanced-glow shadow-2xl"
            style={{ transform: `scale(${logoScale})`, transition: 'transform 0.5s ease-in-out' }}
          >
            <Scale className="w-20 h-20 text-emerald-900" />
          </div>
          
          {/* Enhanced Orbiting Icons */}
          <div className="absolute inset-0 animate-spin-reverse">
            <Brain className={`absolute w-8 h-8 text-purple-400 ${animationPhase >= 1 ? 'animate-enhanced-bounce' : 'opacity-0'} transition-all duration-700`} style={{ top: '5%', left: '50%', transform: 'translateX(-50%)' }} />
            <Bot className={`absolute w-7 h-7 text-emerald-400 ${animationPhase >= 2 ? 'animate-enhanced-pulse' : 'opacity-0'} transition-all duration-700`} style={{ top: '50%', right: '5%', transform: 'translateY(-50%)' }} />
            <Cpu className={`absolute w-7 h-7 text-amber-400 ${animationPhase >= 3 ? 'animate-enhanced-bounce' : 'opacity-0'} transition-all duration-700`} style={{ bottom: '5%', left: '50%', transform: 'translateX(-50%)' }} />
            <Network className={`absolute w-7 h-7 text-cyan-400 ${animationPhase >= 4 ? 'animate-enhanced-pulse' : 'opacity-0'} transition-all duration-700`} style={{ top: '50%', left: '5%', transform: 'translateY(-50%)' }} />
            <Shield className={`absolute w-6 h-6 text-teal-400 ${animationPhase >= 5 ? 'animate-enhanced-bounce' : 'opacity-0'} transition-all duration-700`} style={{ top: '25%', right: '25%' }} />
            <Globe className={`absolute w-6 h-6 text-indigo-400 ${animationPhase >= 5 ? 'animate-enhanced-pulse' : 'opacity-0'} transition-all duration-700`} style={{ bottom: '25%', left: '25%' }} />
          </div>

          {/* Dynamic Particles */}
          <div className="absolute inset-0">
            {[...Array(8)].map((_, i) => (
              <div
                key={`particle-${i}`}
                className={`absolute w-2 h-2 bg-gradient-to-r from-emerald-400 to-teal-400 rounded-full ${animationPhase >= 2 ? 'animate-particle-orbit' : 'opacity-0'}`}
                style={{
                  animationDelay: `${i * 0.5}s`,
                  animationDuration: '4s',
                }}
              />
            ))}
          </div>
        </div>
        
        {/* Enhanced Title with Better Typography */}
        <h1 className="text-7xl md:text-9xl font-bold mb-12 animate-enhanced-fade-in drop-shadow-2xl">
          <span className="bg-gradient-to-r from-white via-emerald-200 to-teal-200 bg-clip-text text-transparent">
            Lawsyde
          </span>
        </h1>
        
        {/* Enhanced Content Section */}
        <div className="space-y-8 animate-enhanced-fade-in-delay">
          {/* Enhanced Free Badge */}
          <div className="inline-flex items-center bg-gradient-to-r from-emerald-500/25 to-teal-500/25 backdrop-blur-lg border border-emerald-300/40 rounded-full px-10 py-5 mb-8 shadow-2xl">
            <Sparkles className="w-7 h-7 text-emerald-300 mr-4 animate-enhanced-pulse" />
            <span className="text-emerald-200 font-bold text-2xl">FREE PLATFORM ACCESS</span>
            <Zap className="w-6 h-6 text-amber-400 ml-4 animate-enhanced-bounce" />
          </div>
          
          {/* Enhanced Taglines */}
          <p className="text-4xl md:text-5xl text-white/95 drop-shadow-2xl mb-6 font-bold leading-tight">
            AI-Powered Legal Network
          </p>
          <p className="text-2xl md:text-3xl text-emerald-200 drop-shadow-xl mb-12 font-medium">
            Athens Immigration & Corporate Lawyers
          </p>
          
          {/* Enhanced Feature Pills */}
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            <div className="bg-white/15 backdrop-blur-sm rounded-full px-6 py-3 border border-white/30">
              <span className="text-white font-semibold">📞 Instant Calls</span>
            </div>
            <div className="bg-white/15 backdrop-blur-sm rounded-full px-6 py-3 border border-white/30">
              <span className="text-white font-semibold">💬 WhatsApp</span>
            </div>
            <div className="bg-white/15 backdrop-blur-sm rounded-full px-6 py-3 border border-white/30">
              <span className="text-white font-semibold">📹 Video Calls</span>
            </div>
            <div className="bg-white/15 backdrop-blur-sm rounded-full px-6 py-3 border border-white/30">
              <span className="text-white font-semibold">🏢 On-site Visits</span>
            </div>
          </div>

          {/* Enhanced AI Processing Animation */}
          <div className="flex justify-center mb-16">
            <div className="flex items-center space-x-4 bg-white/15 backdrop-blur-lg rounded-full px-10 py-5 border border-white/30 shadow-2xl">
              <div className="relative">
                <Brain className="w-8 h-8 text-purple-400 animate-enhanced-pulse" />
                <div className="absolute inset-0 animate-ping opacity-50">
                  <Brain className="w-8 h-8 text-purple-400" />
                </div>
              </div>
              <span className="text-white font-semibold text-lg">{aiText}</span>
              <div className="flex space-x-2">
                <div className="w-3 h-3 bg-gradient-to-r from-emerald-400 to-teal-400 rounded-full animate-enhanced-bounce"></div>
                <div className="w-3 h-3 bg-gradient-to-r from-teal-400 to-cyan-400 rounded-full animate-enhanced-bounce" style={{ animationDelay: '0.2s' }}></div>
                <div className="w-3 h-3 bg-gradient-to-r from-cyan-400 to-blue-400 rounded-full animate-enhanced-bounce" style={{ animationDelay: '0.4s' }}></div>
              </div>
            </div>
          </div>

          {/* Enhanced Features Preview */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 max-w-6xl mx-auto">
            <div className={`bg-white/15 backdrop-blur-lg rounded-2xl p-6 border border-white/30 transform transition-all duration-1000 hover:scale-105 ${animationPhase >= 2 ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'}`}>
              <Users className="w-12 h-12 text-emerald-400 mx-auto mb-4 animate-enhanced-pulse" />
              <h3 className="text-lg font-bold mb-2">Global Network</h3>
              <p className="text-emerald-200 text-sm">Qualified lawyers worldwide</p>
            </div>
            
            <div className={`bg-white/15 backdrop-blur-lg rounded-2xl p-6 border border-white/30 transform transition-all duration-1000 hover:scale-105 ${animationPhase >= 3 ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'}`}>
              <Target className="w-12 h-12 text-teal-400 mx-auto mb-4 animate-enhanced-bounce" />
              <h3 className="text-lg font-bold mb-2">Smart Matching</h3>
              <p className="text-teal-200 text-sm">AI finds perfect lawyer match</p>
            </div>
            
            <div className={`bg-white/15 backdrop-blur-lg rounded-2xl p-6 border border-white/30 transform transition-all duration-1000 hover:scale-105 ${animationPhase >= 4 ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'}`}>
              <CheckCircle className="w-12 h-12 text-amber-400 mx-auto mb-4 animate-enhanced-pulse" />
              <h3 className="text-lg font-bold mb-2">Free Services</h3>
              <p className="text-amber-200 text-sm">All connections completely free</p>
            </div>
            
            <div className={`bg-white/15 backdrop-blur-lg rounded-2xl p-6 border border-white/30 transform transition-all duration-1000 hover:scale-105 ${animationPhase >= 5 ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'}`}>
              <Award className="w-12 h-12 text-cyan-400 mx-auto mb-4 animate-enhanced-bounce" />
              <h3 className="text-lg font-bold mb-2">Verified Lawyers</h3>
              <p className="text-cyan-200 text-sm">Qualified legal professionals</p>
            </div>
          </div>

          {/* Enhanced Progress Indicator */}
          <div className="mt-16 flex justify-center">
            <div className="bg-white/10 backdrop-blur-sm rounded-full px-8 py-3 border border-white/20">
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-emerald-400 rounded-full animate-enhanced-pulse"></div>
                <span className="text-white/90 text-sm font-medium">Launching in {Math.max(0, 6 - Math.floor(Date.now() / 1000) % 6)} seconds</span>
              </div>
            </div>
          </div>
        </div>

        <style jsx>{`
          @keyframes enhancedGlow {
            0% {
              box-shadow: 0 0 30px rgba(16, 185, 129, 0.6), 0 0 60px rgba(13, 148, 136, 0.4);
              filter: brightness(1);
            }
            50% {
              box-shadow: 0 0 60px rgba(13, 148, 136, 0.8), 0 0 120px rgba(16, 185, 129, 0.6), 0 0 180px rgba(8, 145, 178, 0.4);
              filter: brightness(1.2);
            }
            100% {
              box-shadow: 0 0 30px rgba(16, 185, 129, 0.6), 0 0 60px rgba(13, 148, 136, 0.4);
              filter: brightness(1);
            }
          }
          
          @keyframes enhancedFadeIn {
            0% {
              opacity: 0;
              transform: translateY(40px) scale(0.9);
            }
            100% {
              opacity: 1;
              transform: translateY(0) scale(1);
            }
          }
          
          @keyframes enhancedFadeInDelay {
            0% {
              opacity: 0;
              transform: translateY(30px);
            }
            100% {
              opacity: 1;
              transform: translateY(0);
            }
          }
          
          @keyframes enhancedPulse {
            0%, 100% {
              transform: scale(1);
              opacity: 0.8;
            }
            50% {
              transform: scale(1.2);
              opacity: 1;
            }
          }
          
          @keyframes enhancedBounce {
            0%, 100% {
              transform: translateY(0) scale(1);
            }
            25% {
              transform: translateY(-8px) scale(1.05);
            }
            50% {
              transform: translateY(-4px) scale(1.02);
            }
            75% {
              transform: translateY(-12px) scale(1.08);
            }
          }
          
          @keyframes particleOrbit {
            0% {
              transform: rotate(0deg) translateX(80px) rotate(0deg);
              opacity: 0;
            }
            10% {
              opacity: 1;
            }
            90% {
              opacity: 1;
            }
            100% {
              transform: rotate(360deg) translateX(80px) rotate(-360deg);
              opacity: 0;
            }
          }
          
          @keyframes spinSlow {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
          }
          
          @keyframes spinReverse {
            from { transform: rotate(360deg); }
            to { transform: rotate(0deg); }
          }
          
          .animate-enhanced-glow {
            animation: enhancedGlow 4s ease-in-out infinite;
          }
          
          .animate-enhanced-fade-in {
            animation: enhancedFadeIn 1.5s ease-out forwards;
          }
          
          .animate-enhanced-fade-in-delay {
            animation: enhancedFadeInDelay 1.5s ease-out 0.5s forwards;
            opacity: 0;
          }
          
          .animate-enhanced-pulse {
            animation: enhancedPulse 2.5s ease-in-out infinite;
          }
          
          .animate-enhanced-bounce {
            animation: enhancedBounce 3s ease-in-out infinite;
          }
          
          .animate-particle-orbit {
            animation: particleOrbit 4s linear infinite;
          }
          
          .animate-spin-slow {
            animation: spinSlow 12s linear infinite;
          }
          
          .animate-spin-reverse {
            animation: spinReverse 10s linear infinite;
          }
        `}</style>
      </div>
    </div>
  );
};

export default SplashScreen;