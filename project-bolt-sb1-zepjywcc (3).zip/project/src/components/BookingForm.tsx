import React, { useState } from 'react';
import { supabase, Profile } from '../lib/supabase';
import { Calendar, Clock, Video, MapPin, Check } from 'lucide-react';

interface BookingFormProps {
  clientProfile: Profile;
  lawyerProfile: Profile;
  onBookingConfirmed: () => void;
}

const BookingForm: React.FC<BookingFormProps> = ({
  clientProfile,
  lawyerProfile,
  onBookingConfirmed
}) => {
  const [appointmentType, setAppointmentType] = useState<'video' | 'in-person'>('video');
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);

  const handleBooking = async () => {
    if (!selectedDate || !selectedTime) {
      alert('Please select both date and time');
      return;
    }

    setLoading(true);
    try {
      const scheduledAt = new Date(`${selectedDate}T${selectedTime}`).toISOString();
      
      const { error } = await supabase.from('appointments').insert({
        client_id: clientProfile.id,
        lawyer_id: lawyerProfile.id,
        type: appointmentType,
        scheduled_at: scheduledAt,
        status: 'confirmed',
        description
      });

      if (error) throw error;
      onBookingConfirmed();
    } catch (error: any) {
      alert(error.message);
    } finally {
      setLoading(false);
    }
  };

  // Generate time slots
  const timeSlots = [];
  for (let hour = 9; hour < 18; hour++) {
    for (let minute = 0; minute < 60; minute += 30) {
      const time = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
      timeSlots.push(time);
    }
  }

  return (
    <div className="bg-gray-50 rounded-xl p-6 mt-4 space-y-6">
      <h4 className="text-lg font-semibold text-gray-800 flex items-center">
        <Calendar className="w-5 h-5 mr-2 text-blue-600" />
        Book Appointment
      </h4>

      {/* Appointment Type */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Appointment Type
        </label>
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => setAppointmentType('video')}
            className={`flex items-center justify-center p-4 rounded-xl border-2 transition-all duration-300 transform hover:scale-110 shadow-lg font-bold ${
              appointmentType === 'video'
                ? 'border-blue-500 bg-gradient-to-r from-blue-50 to-blue-100 text-blue-700 shadow-blue-500/30'
                : 'border-gray-300 hover:border-blue-400 hover:bg-blue-50 hover:shadow-blue-500/20'
            }`}
          >
            <Video className="w-4 h-4 mr-2" />
            Video Call
          </button>
          <button
            onClick={() => setAppointmentType('in-person')}
            className={`flex items-center justify-center p-4 rounded-xl border-2 transition-all duration-300 transform hover:scale-110 shadow-lg font-bold ${
              appointmentType === 'in-person'
                ? 'border-blue-500 bg-gradient-to-r from-blue-50 to-blue-100 text-blue-700 shadow-blue-500/30'
                : 'border-gray-300 hover:border-blue-400 hover:bg-blue-50 hover:shadow-blue-500/20'
            }`}
          >
            <MapPin className="w-4 h-4 mr-2" />
            In Person
          </button>
        </div>
      </div>

      {/* Date Selection */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Date
          </label>
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            min={new Date().toISOString().split('T')[0]}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Time
          </label>
          <select
            value={selectedTime}
            onChange={(e) => setSelectedTime(e.target.value)}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="">Select time</option>
            {timeSlots.map((time) => (
              <option key={time} value={time}>
                {time}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Description */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Description (Optional)
        </label>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Brief description of your legal matter..."
          rows={3}
          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
        />
      </div>

      {/* Book Button */}
      <button
        onClick={handleBooking}
        disabled={loading || !selectedDate || !selectedTime}
        className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white py-4 rounded-xl font-bold text-lg transition-all duration-300 transform hover:scale-110 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100 flex items-center justify-center shadow-xl hover:shadow-blue-500/60 border-2 border-blue-300/30 hover:border-blue-200 relative overflow-hidden"
      >
        <span className="relative z-10 flex items-center">
          {loading ? (
            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
          ) : (
            <>
              <Check className="w-5 h-5 mr-2" />
              Confirm Booking
            </>
          )}
        </span>
        {!loading && (
          <div className="absolute inset-0 bg-gradient-to-r from-blue-400 to-purple-400 opacity-0 hover:opacity-30 transition-opacity duration-300"></div>
        )}
      </button>
    </div>
  );
};

export default BookingForm;