import React, { useState, useEffect } from 'react';
import { supabase, Profile, Appointment } from '../lib/supabase';
import { Calendar, Clock, User, Video, MapPin, ArrowLeft } from 'lucide-react';
import { format, parseISO } from 'date-fns';

interface CalendarViewProps {
  userProfile: Profile;
}

const CalendarView: React.FC<CalendarViewProps> = ({ userProfile }) => {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAppointments();
  }, [userProfile.id]);

  const fetchAppointments = async () => {
    try {
      const { data, error } = await supabase
        .from('appointments')
        .select(`
          *,
          client_profile:profiles!appointments_client_id_fkey(*),
          lawyer_profile:profiles!appointments_lawyer_id_fkey(*)
        `)
        .eq(userProfile.role === 'lawyer' ? 'lawyer_id' : 'client_id', userProfile.id)
        .order('scheduled_at', { ascending: true });

      if (error) throw error;
      setAppointments(data || []);
    } catch (error: any) {
      console.error('Error fetching appointments:', error.message);
    } finally {
      setLoading(false);
    }
  };

  const joinVideoCall = (appointmentId: string) => {
    const roomName = `lawsyde-${appointmentId}`;
    const jitsiUrl = `https://meet.jit.si/${roomName}`;
    window.open(jitsiUrl, '_blank');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center mb-6">
        <button
          onClick={() => window.history.back()}
          className="mr-4 p-2 hover:bg-gray-100 rounded-full transition-colors duration-200"
          title="Back"
        >
          <ArrowLeft className="w-5 h-5 text-gray-600" />
        </button>
        <Calendar className="w-6 h-6 text-blue-600 mr-3" />
        <h2 className="text-2xl font-bold text-gray-800">
          {userProfile.role === 'lawyer' ? 'My Schedule' : 'My Appointments'}
        </h2>
      </div>

      {appointments.length === 0 ? (
        <div className="text-center py-12 bg-gray-50 rounded-xl">
          <Calendar className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-600 mb-2">No appointments scheduled</h3>
          <p className="text-gray-500">
            {userProfile.role === 'lawyer' 
              ? 'Clients will be able to book appointments with you'
              : 'Browse lawyers to book your first appointment'}
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {appointments.map((appointment) => {
            const otherProfile = userProfile.role === 'lawyer' 
              ? appointment.client_profile 
              : appointment.lawyer_profile;
              
            return (
              <div
                key={appointment.id}
                className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-lg transition-shadow duration-300"
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center mb-3">
                      <User className="w-5 h-5 text-gray-600 mr-2" />
                      <h3 className="text-lg font-semibold text-gray-800">
                        {otherProfile?.full_name || 'Unknown User'}
                      </h3>
                      <span className={`ml-3 px-2 py-1 text-xs rounded-full ${
                        appointment.status === 'confirmed' ? 'bg-green-100 text-green-800' :
                        appointment.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {appointment.status}
                      </span>
                    </div>

                    <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
                      <div className="flex items-center">
                        <Clock className="w-4 h-4 mr-1" />
                        {format(parseISO(appointment.scheduled_at), 'MMM dd, yyyy HH:mm')}
                      </div>
                      <div className="flex items-center">
                        {appointment.type === 'video' ? (
                          <Video className="w-4 h-4 mr-1" />
                        ) : (
                          <MapPin className="w-4 h-4 mr-1" />
                        )}
                        {appointment.type === 'video' ? 'Video Call' : 'In Person'}
                      </div>
                    </div>

                    {appointment.description && (
                      <p className="text-gray-700 text-sm">{appointment.description}</p>
                    )}
                  </div>

                  <div className="mt-4 md:mt-0 md:ml-6 flex space-x-3">
                    {appointment.type === 'video' && (
                      <button
                        onClick={() => joinVideoCall(appointment.id)}
                        className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white px-6 py-3 rounded-xl font-bold transition-all duration-300 transform hover:scale-110 flex items-center shadow-lg hover:shadow-blue-500/50 border-2 border-blue-300/30 hover:border-blue-200"
                      >
                        <Video className="w-4 h-4 mr-2" />
                        Join Call
                      </button>
                    )}
                    
                    {otherProfile?.phone && (
                      <a
                        href={`tel:${otherProfile.phone}`}
                        className="bg-gradient-to-r from-gray-200 to-gray-100 hover:from-gray-300 hover:to-gray-200 text-gray-800 px-6 py-3 rounded-xl font-bold transition-all duration-300 shadow-lg hover:shadow-gray-500/30 transform hover:scale-110 border-2 border-gray-300/50"
                      >
                        Call
                      </a>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default CalendarView;