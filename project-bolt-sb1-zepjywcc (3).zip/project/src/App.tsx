import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { supabase } from './lib/supabase';
import LandingPage from './pages/LandingPage';
import AuthPage from './pages/AuthPage';
import RoleSelection from './pages/RoleSelection';
import Dashboard from './pages/Dashboard';
import LawyerRegistration from './pages/LawyerRegistration';

function App() {
  const [session, setSession] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [isDemo, setIsDemo] = useState(false);

  useEffect(() => {
    // Check if we're in demo mode (missing env vars)
    const hasSupabaseConfig = import.meta.env.VITE_SUPABASE_URL && import.meta.env.VITE_SUPABASE_ANON_KEY;
    setIsDemo(!hasSupabaseConfig);
    
    if (hasSupabaseConfig) {
      // Get initial session
      supabase.auth.getSession().then(({ data: { session } }) => {
        setSession(session);
        setLoading(false);
      });

      // Listen for auth changes
      const {
        data: { subscription },
      } = supabase.auth.onAuthStateChange((_event, session) => {
        setSession(session);
      });

      return () => subscription.unsubscribe();
    } else {
      setLoading(false);
    }
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-600 to-purple-600">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white"></div>
      </div>
    );
  }

  return (
    <Router>
      <div className="App">
        {isDemo && (
          <div className="bg-yellow-500 text-black px-4 py-2 text-center font-medium">
            🚧 Demo Mode: Supabase not configured. Some features may be limited.
          </div>
        )}
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route 
            path="/auth" 
            element={session ? <Navigate to="/dashboard" /> : <AuthPage />} 
          />
          <Route 
            path="/role-selection" 
            element={session || isDemo ? <RoleSelection /> : <Navigate to="/auth" />} 
          />
          <Route 
            path="/dashboard" 
            element={session || isDemo ? <Dashboard /> : <Navigate to="/auth" />} 
          />
          <Route 
            path="/lawyer-registration" 
            element={<LawyerRegistration />} 
          />
        </Routes>
      </div>
    </Router>
  );
}

export default App;