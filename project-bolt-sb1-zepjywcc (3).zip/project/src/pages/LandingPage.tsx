import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Scale, ArrowRight, Globe, Star, Clock, MapPin, Phone, MessageCircle, Users, Shield, Award, CheckCircle, Brain, Sparkles, Zap, Bot, Cpu, Network, Eye, Lightbulb, Rocket, Target, Heart, Calendar, UserPlus } from 'lucide-react';
import ModernBackground from '../components/ModernBackground';
import SplashScreen from '../components/SplashScreen';
import BookingModal from '../components/BookingModal';
import { featuredLawyers } from '../lib/supabase';

const LandingPage: React.FC = () => {
  const [showSplash, setShowSplash] = useState(true);
  const [selectedLawyer, setSelectedLawyer] = useState<any>(null);
  const [showBookingModal, setShowBookingModal] = useState(false);
  const navigate = useNavigate();

  const handleGetStarted = () => {
    navigate('/auth');
  };

  const handleContactLawyer = (lawyer: any, method: 'call' | 'whatsapp' | 'facebook') => {
    switch (method) {
      case 'call':
        window.open(`tel:${lawyer.phone}`, '_self');
        break;
      case 'whatsapp':
        window.open(`https://wa.me/${lawyer.phone.replace(/\D/g, '')}`, '_blank');
        break;
      case 'facebook':
        window.open(lawyer.facebook, '_blank');
        break;
    }
  };

  const handleBookLawyer = (lawyer: any) => {
    setSelectedLawyer(lawyer);
    setShowBookingModal(true);
  };

  if (showSplash) {
    return <SplashScreen onComplete={() => setShowSplash(false)} />;
  }

  return (
    <div className="min-h-screen text-white overflow-hidden relative">
      <ModernBackground />
      
      {/* Navigation */}
      <nav className="relative z-20 flex items-center justify-between p-6">
        <div className="flex items-center">
          <div className="relative">
            <Scale className="w-8 h-8 text-white mr-3" />
            <Sparkles className="absolute -top-1 -right-1 w-4 h-4 text-yellow-400 animate-pulse" />
          </div>
          <span className="text-2xl font-bold">Lawsyde</span>
          <span className="ml-2 text-xs bg-gradient-to-r from-green-400 to-blue-400 px-2 py-1 rounded-full text-black font-semibold animate-pulse">
            AI-POWERED
          </span>
        </div>
        <div className="flex items-center space-x-4">
          <button
            onClick={handleGetStarted}
            className="bg-gradient-to-r from-emerald-500/80 to-teal-500/80 backdrop-blur-sm hover:from-emerald-400 hover:to-teal-400 px-8 py-3 rounded-full font-bold transition-all duration-300 border border-emerald-300/50 group shadow-lg hover:shadow-emerald-500/50 transform hover:scale-110"
          >
            <span className="mr-2 text-white">Get Started</span>
            <ArrowRight className="inline w-4 h-4 group-hover:translate-x-1 transition-transform duration-300" />
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-6 -mt-20">
        <div className="text-center max-w-6xl mx-auto">
          <div className="mb-12">
            {/* Revolutionary AI Badge */}
            <div className="inline-flex items-center bg-gradient-to-r from-purple-500/20 to-blue-500/20 backdrop-blur-sm border border-purple-300/30 rounded-full px-8 py-4 mb-8 group hover:scale-105 transition-transform duration-300">
              <Brain className="w-6 h-6 text-purple-300 mr-3 animate-pulse" />
              <span className="text-purple-200 font-bold text-lg">Revolutionary AI Legal Technology</span>
              <Zap className="w-5 h-5 text-yellow-400 ml-3 animate-bounce" />
            </div>

            <h1 className="text-6xl md:text-8xl font-bold mb-8 bg-gradient-to-r from-white via-blue-200 to-purple-200 bg-clip-text text-transparent leading-tight animate-fade-in-up">
              Global Legal Network
              <br />
              <span className="text-5xl md:text-7xl bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">
                Powered by AI
              </span>
            </h1>
            
            <p className="text-xl md:text-2xl text-blue-100 mb-8 leading-relaxed max-w-5xl mx-auto animate-fade-in-up-delay">
              Revolutionary AI platform connecting clients with qualified lawyers worldwide. Starting with Athens specialists in immigration and corporate law.
              <span className="text-green-300 font-bold"> Instant connections</span> through multiple channels. 
              Connect with Athens lawyers instantly through calls, WhatsApp, and Facebook. Book video calls or on-site meetings - platform access is free.
            </p>

            {/* Mission Statement */}
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 mb-12 border border-white/20 max-w-4xl mx-auto">
              <div className="flex items-center justify-center mb-4">
                <Heart className="w-6 h-6 text-red-400 mr-2 animate-pulse" />
                <span className="text-lg font-bold text-white">Global Legal Platform</span>
                <Heart className="w-6 h-6 text-red-400 ml-2 animate-pulse" />
              </div>
              <p className="text-blue-200 text-lg leading-relaxed">
                "Connecting clients with qualified lawyers worldwide using AI technology. 
                Starting with Athens specialists. Instant communication through calls, WhatsApp, and Facebook. Professional video calls and on-site meetings available."
              </p>
            </div>
          </div>

          {/* AI Features Showcase */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20 group hover:bg-white/20 transition-all duration-300 transform hover:scale-105">
              <Bot className="w-12 h-12 text-blue-400 mx-auto mb-4 group-hover:scale-110 transition-transform duration-300 animate-pulse" />
              <h3 className="text-xl font-bold mb-2">Global Lawyer Network</h3>
              <p className="text-blue-200 text-sm">AI analyzes your needs and connects you with qualified lawyers worldwide</p>
            </div>
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20 group hover:bg-white/20 transition-all duration-300 transform hover:scale-105">
              <Cpu className="w-12 h-12 text-purple-400 mx-auto mb-4 group-hover:scale-110 transition-transform duration-300 animate-pulse" />
              <h3 className="text-xl font-bold mb-2">Multiple Channels</h3>
              <p className="text-blue-200 text-sm">Connect via phone, WhatsApp, Facebook, video calls, or schedule on-site meetings</p>
            </div>
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20 group hover:bg-white/20 transition-all duration-300 transform hover:scale-105">
              <Network className="w-12 h-12 text-green-400 mx-auto mb-4 group-hover:scale-110 transition-transform duration-300 animate-pulse" />
              <h3 className="text-xl font-bold mb-2">AI-Enhanced Platform</h3>
              <p className="text-blue-200 text-sm">Smart matching with AI-enhanced communication tools for seamless connections</p>
            </div>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
            <button
              onClick={handleGetStarted}
              className="group bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 px-12 py-6 rounded-2xl text-2xl font-bold transition-all duration-300 transform hover:scale-110 shadow-2xl hover:shadow-emerald-500/50 relative overflow-hidden border-2 border-emerald-300/30 hover:border-emerald-200"
            >
              <span className="relative z-10 flex items-center">
                <Sparkles className="w-6 h-6 mr-3 animate-pulse" />
                Find Your Lawyer
                <ArrowRight className="inline-block ml-3 w-6 h-6 group-hover:translate-x-1 transition-transform duration-300" />
              </span>
              <div className="absolute inset-0 bg-gradient-to-r from-emerald-300 to-teal-300 opacity-0 group-hover:opacity-30 transition-opacity duration-300"></div>
              <div className="absolute inset-0 animate-pulse bg-gradient-to-r from-emerald-400/20 to-teal-400/20 rounded-2xl"></div>
            </button>
            
            <button
              onClick={() => navigate('/lawyer-registration')}
              className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 px-12 py-6 rounded-2xl text-2xl font-bold transition-all duration-300 transform hover:scale-110 border-2 border-amber-300/50 hover:border-amber-200 group shadow-2xl hover:shadow-amber-500/50 relative overflow-hidden"
            >
              <span className="relative z-10 flex items-center">
                <UserPlus className="inline w-6 h-6 mr-3" />
                Join as Lawyer
                <ArrowRight className="inline-block ml-3 w-6 h-6 group-hover:translate-x-1 transition-transform duration-300" />
              </span>
              <div className="absolute inset-0 bg-gradient-to-r from-amber-300 to-orange-300 opacity-0 group-hover:opacity-30 transition-opacity duration-300"></div>
              <div className="absolute inset-0 animate-pulse bg-gradient-to-r from-amber-400/20 to-orange-400/20 rounded-2xl"></div>
            </button>
          </div>

          {/* Trust Indicators */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
            <div className="text-center group">
              <div className="w-20 h-20 bg-gradient-to-r from-emerald-400 to-teal-400 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300 animate-ai-glow">
                <Users className="w-10 h-10 text-white" />
              </div>
              <div className="text-3xl font-bold">50+</div>
              <div className="text-emerald-200 text-sm">Athens Lawyers</div>
            </div>
            <div className="text-center group">
              <div className="w-20 h-20 bg-gradient-to-r from-amber-400 to-orange-400 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300 animate-ai-glow">
                <Bot className="w-10 h-10 text-white animate-pulse" />
              </div>
              <div className="text-3xl font-bold">24/7</div>
              <div className="text-emerald-200 text-sm">AI Matching</div>
            </div>
            <div className="text-center group">
              <div className="w-20 h-20 bg-gradient-to-r from-teal-400 to-cyan-400 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300 animate-ai-glow">
                <Zap className="w-10 h-10 text-white animate-bounce" />
              </div>
              <div className="text-3xl font-bold">&lt;10s</div>
              <div className="text-emerald-200 text-sm">Connection Time</div>
            </div>
            <div className="text-center group">
              <div className="w-20 h-20 bg-gradient-to-r from-rose-400 to-pink-400 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300 animate-ai-glow">
                <Globe className="w-10 h-10 text-white" />
              </div>
              <div className="text-3xl font-bold">Global</div>
              <div className="text-emerald-200 text-sm">Platform Access</div>
            </div>
          </div>
        </div>
      </div>


      {/* Footer */}
      <footer className="relative z-10 py-8 md:py-12 px-4 md:px-6 border-t border-white/20">
        <div className="max-w-7xl mx-auto text-center">
          <div className="flex items-center justify-center mb-6">
            <div className="relative">
              <Scale className="w-6 h-6 md:w-8 md:h-8 text-white mr-2 md:mr-3" />
              <Sparkles className="absolute -top-1 -right-1 w-3 h-3 md:w-4 md:h-4 text-yellow-400 animate-pulse" />
            </div>
            <span className="text-xl md:text-2xl font-bold">Lawsyde</span>
            <span className="ml-2 text-xs bg-gradient-to-r from-green-400 to-blue-400 px-2 py-1 rounded-full text-black font-semibold animate-pulse">
              AI-POWERED
            </span>
          </div>
          <p className="text-blue-200 mb-3 md:mb-4 text-sm md:text-lg px-2">
            Global Legal Network • AI Matching • Professional Connections • Worldwide Access
          </p>
          <p className="text-indigo-300 text-xs md:text-sm px-2">
            © 2025 Lawsyde. Connecting clients with qualified lawyers worldwide through AI-powered smart matching technology.
          </p>
        </div>
      </footer>

      {/* Booking Modal */}
    </div>
  );
};

export default LandingPage;