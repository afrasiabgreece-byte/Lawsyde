import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase, Profile, featuredLawyers } from '../lib/supabase';
import { LogOut, Scale, User, Phone, MessageCircle, Star, Clock, MapPin, Brain, Zap, Target, CheckCircle, Heart, Sparkles, ArrowLeft } from 'lucide-react';
import BookingForm from '../components/BookingForm';
import CalendarView from '../components/CalendarView';
import BookingModal from '../components/BookingModal';

const Dashboard: React.FC = () => {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [selectedLawyer, setSelectedLawyer] = useState<any>(null);
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        navigate('/auth');
        return;
      }

      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();

      if (error) throw error;
      setProfile(data);
    } catch (error: any) {
      console.error('Error fetching profile:', error.message);
      navigate('/role-selection');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate('/');
  };

  const handleContactLawyer = (lawyer: any, method: 'call' | 'whatsapp' | 'facebook') => {
    switch (method) {
      case 'call':
        window.open(`tel:${lawyer.phone}`, '_self');
        break;
      case 'whatsapp':
        window.open(`https://wa.me/${lawyer.phone.replace(/\D/g, '')}`, '_blank');
        break;
      case 'facebook':
        window.open(lawyer.facebook, '_blank');
        break;
    }
  };

  const handleBookLawyer = (lawyer: any) => {
    setSelectedLawyer(lawyer);
    setShowBookingModal(true);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600 mb-4">Unable to load profile</p>
          <button
            onClick={() => navigate('/role-selection')}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg"
          >
            Setup Profile
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button
                onClick={() => navigate('/')}
                className="mr-4 p-2 hover:bg-gray-100 rounded-full transition-colors duration-200"
                title="Back to Home"
              >
                <ArrowLeft className="w-5 h-5 text-gray-600" />
              </button>
              <Scale className="w-8 h-8 text-blue-600 mr-3" />
              <div>
                <h1 className="text-2xl font-bold text-gray-800">
                  Welcome back, {profile.full_name}! 👋
                </h1>
                <p className="text-gray-600 capitalize">
                  {profile.role} Dashboard
                </p>
              </div>
            </div>
            
            <button
              onClick={handleLogout}
              className="flex items-center bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg transition-colors duration-300"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {profile.role === 'client' ? (
          <div className="space-y-8">
            {/* Athens Immigration & Corporate Lawyers */}
            <section>
              <div className="flex items-center mb-6">
                <Scale className="w-6 h-6 text-blue-600 mr-3" />
                <h2 className="text-2xl font-bold text-gray-800">Athens Immigration & Corporate Lawyers</h2>
                <div className="ml-4 bg-gradient-to-r from-emerald-500 to-teal-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
                  All Services Free
                </div>
              </div>
              
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {featuredLawyers.map((lawyer) => (
                  <div
                    key={lawyer.id}
                    className="bg-white rounded-xl p-6 shadow-md hover:shadow-xl transition-all duration-300 transform hover:scale-105 border border-gray-100 group relative overflow-hidden"
                  >
                    {/* AI Enhancement Badge */}
                    <div className="absolute top-3 right-3">
                      <div className="flex items-center bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full px-3 py-1">
                        <Brain className="w-4 h-4 text-white mr-1" />
                        <span className="text-xs text-white font-bold">AI {lawyer.aiScore}</span>
                      </div>
                    </div>

                    <div className="flex items-center mb-6 mt-8">
                      <div className="relative">
                        <img
                          src={lawyer.image}
                          alt={lawyer.name}
                          className="w-16 h-16 rounded-full object-cover mr-4 border-2 border-gray-200"
                        />
                        <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                          <div className="w-3 h-3 bg-white rounded-full"></div>
                        </div>
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-gray-800">{lawyer.name}</h3>
                        <p className="text-indigo-600 font-medium">{lawyer.specialty}</p>
                        <div className="flex items-center mt-1">
                          <MapPin className="w-4 h-4 text-indigo-500 mr-1" />
                          <span className="text-sm text-indigo-500">{lawyer.location}</span>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-3 mb-6">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <Star className="w-4 h-4 text-yellow-400 mr-1" />
                          <span className="text-gray-800 font-semibold">{lawyer.rating}</span>
                          <span className="text-gray-600 text-sm ml-1">({lawyer.reviews} reviews)</span>
                        </div>
                        <div className="flex items-center">
                          <Zap className="w-4 h-4 text-indigo-500 mr-1" />
                          <span className="text-indigo-600 text-sm font-semibold">{lawyer.responseTime}</span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <Target className="w-4 h-4 text-emerald-500 mr-1" />
                          <span className="text-emerald-600 text-sm">{lawyer.casesResolved} cases resolved</span>
                        </div>
                        <div className="flex items-center">
                          <CheckCircle className="w-4 h-4 text-green-500 mr-1" />
                          <span className="text-green-600 text-sm font-semibold">{lawyer.availability}</span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <Brain className="w-4 h-4 text-purple-500 mr-1 animate-pulse" />
                          <span className="text-purple-600 text-sm">AI-Enhanced</span>
                        </div>
                        <div className="flex items-center">
                          <Heart className="w-4 h-4 text-red-500 mr-1 animate-pulse" />
                          <span className="text-red-600 text-sm font-semibold">Helping Society</span>
                        </div>
                      </div>
                    </div>

                    <div className="mb-6">
                      <div className="space-y-3 mb-4">
                        <div className="text-lg font-bold text-indigo-600 flex items-center justify-center">
                          <Sparkles className="w-5 h-5 mr-2" />
                          Professional Connectivity - All Services Free
                        </div>
                        <div className="text-sm text-gray-600 text-center">
                          📞 Call • 💬 WhatsApp • 📘 Facebook • 📹 Video Calls • 🏢 On-site Visits
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-1 justify-center">
                        {lawyer.languages.map((lang) => (
                          <span key={lang} className="bg-indigo-100 text-indigo-700 px-2 py-1 rounded-full text-xs border border-indigo-200">
                            {lang}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-2 mb-4">
                      <button
                        onClick={() => handleContactLawyer(lawyer, 'call')}
                        className="bg-gradient-to-r from-indigo-100 to-indigo-50 hover:from-indigo-200 hover:to-indigo-100 text-indigo-700 px-3 py-4 rounded-xl text-sm font-bold transition-all duration-300 flex items-center justify-center group shadow-lg hover:shadow-indigo-500/30 transform hover:scale-110 border-2 border-indigo-200/50 hover:border-indigo-300"
                      >
                        <span className="text-lg group-hover:animate-bounce">📞</span>
                      </button>
                      <button
                        onClick={() => handleContactLawyer(lawyer, 'whatsapp')}
                        className="bg-gradient-to-r from-emerald-100 to-emerald-50 hover:from-emerald-200 hover:to-emerald-100 text-emerald-700 px-3 py-4 rounded-xl text-sm font-bold transition-all duration-300 flex items-center justify-center group shadow-lg hover:shadow-emerald-500/30 transform hover:scale-110 border-2 border-emerald-200/50 hover:border-emerald-300"
                      >
                        <span className="text-lg group-hover:animate-bounce">💬</span>
                      </button>
                      <button
                        onClick={() => handleContactLawyer(lawyer, 'facebook')}
                        className="bg-gradient-to-r from-cyan-100 to-cyan-50 hover:from-cyan-200 hover:to-cyan-100 text-cyan-700 px-3 py-4 rounded-xl text-sm font-bold transition-all duration-300 flex items-center justify-center group shadow-lg hover:shadow-cyan-500/30 transform hover:scale-110 border-2 border-cyan-200/50 hover:border-cyan-300"
                      >
                        <span className="text-lg group-hover:animate-bounce">📘</span>
                      </button>
                    </div>

                    <button
                      onClick={() => handleBookLawyer(lawyer)}
                      className="w-full bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-400 hover:to-purple-400 text-white px-4 py-4 rounded-xl text-lg font-bold transition-all duration-300 flex items-center justify-center group shadow-xl hover:shadow-indigo-500/60 transform hover:scale-110 border-2 border-indigo-300/30 hover:border-indigo-200 relative overflow-hidden"
                    >
                      <Brain className="w-5 h-5 mr-2 animate-pulse" />
                      Connect Now
                      <div className="absolute inset-0 bg-gradient-to-r from-indigo-300 to-purple-300 opacity-0 group-hover:opacity-40 transition-opacity duration-300"></div>
                      <div className="absolute inset-0 animate-pulse bg-gradient-to-r from-indigo-400/20 to-purple-400/20 rounded-xl"></div>
                    </button>
                  </div>
                ))}
              </div>
            </section>

            {/* Client's Appointments */}
            <section>
              <CalendarView userProfile={profile} />
            </section>
          </div>
        ) : (
          /* Lawyer Dashboard */
          <div className="space-y-8">
            {/* Lawyer Stats */}
            <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white rounded-xl p-6 shadow-md">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-600 text-sm">Total Appointments</p>
                    <p className="text-2xl font-bold text-gray-800">12</p>
                  </div>
                  <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center">
                    <Clock className="w-6 h-6 text-indigo-600" />
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-md">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-600 text-sm">This Month</p>
                    <p className="text-2xl font-bold text-gray-800">8</p>
                  </div>
                  <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center">
                    <User className="w-6 h-6 text-emerald-600" />
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-md">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-600 text-sm">Rating</p>
                    <p className="text-2xl font-bold text-gray-800">4.9</p>
                  </div>
                  <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center">
                    <Star className="w-6 h-6 text-amber-600" />
                  </div>
                </div>
              </div>
            </section>

            {/* Lawyer's Schedule */}
            <section>
              <CalendarView userProfile={profile} />
            </section>
          </div>
        )}
      </main>

      {/* Booking Modal for Clients */}
      {profile.role === 'client' && (
        <BookingModal
          lawyer={selectedLawyer}
          isOpen={showBookingModal}
          onClose={() => {
            setShowBookingModal(false);
            setSelectedLawyer(null);
          }}
          userProfile={profile}
        />
      )}
    </div>
  );
};

export default Dashboard;