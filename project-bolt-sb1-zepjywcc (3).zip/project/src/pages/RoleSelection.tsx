import React from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { Users, Scale, ArrowRight, ArrowLeft } from 'lucide-react';
import ModernBackground from '../components/ModernBackground';

const RoleSelection: React.FC = () => {
  const navigate = useNavigate();

  const handleRoleSelection = async (role: 'client' | 'lawyer') => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (user) {
        const { error } = await supabase.from('profiles').upsert({
          id: user.id,
          role,
          full_name: user.user_metadata?.full_name || user.email?.split('@')[0] || 'User',
          email: user.email
        });

        if (error) throw error;
        navigate('/dashboard');
      }
    } catch (error: any) {
      alert(error.message);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-6 relative">
      <ModernBackground />
      
      {/* Back Button */}
      <button
        onClick={() => navigate('/auth')}
        className="absolute top-6 left-6 z-20 bg-white/10 backdrop-blur-lg hover:bg-white/20 text-white p-3 rounded-full transition-all duration-300 transform hover:scale-110 border border-white/30 hover:border-white/50 shadow-lg hover:shadow-white/30"
      >
        <ArrowLeft className="w-5 h-5" />
      </button>

      <div className="text-center max-w-2xl mx-auto relative z-10">
        <div className="mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Choose Your Role
          </h2>
          <p className="text-xl text-blue-200">
            How would you like to use Lawsyde today?
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <div className="group">
            <button
              onClick={() => handleRoleSelection('client')}
              className="w-full bg-gradient-to-br from-white/15 to-white/5 backdrop-blur-lg hover:from-white/25 hover:to-white/15 border-2 border-white/30 hover:border-emerald-300/60 rounded-2xl p-10 transition-all duration-300 transform hover:scale-110 hover:shadow-2xl hover:shadow-emerald-500/50 relative overflow-hidden"
            >
              <Users className="w-16 h-16 text-emerald-300 mx-auto mb-6 group-hover:scale-110 transition-transform duration-300" />
              <h3 className="text-2xl font-bold text-white mb-4">I'm a Client</h3>
              <p className="text-emerald-200 mb-6">
                Find and book appointments with qualified lawyers for your legal needs
              </p>
              <div className="flex items-center justify-center text-teal-300 group-hover:text-white transition-colors duration-300">
                <span className="mr-2">Get Started</span>
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
              </div>
              <div className="absolute inset-0 bg-gradient-to-br from-emerald-400/10 to-teal-400/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </button>
          </div>

          <div className="group">
            <button
              onClick={() => handleRoleSelection('lawyer')}
              className="w-full bg-gradient-to-br from-white/15 to-white/5 backdrop-blur-lg hover:from-white/25 hover:to-white/15 border-2 border-white/30 hover:border-amber-300/60 rounded-2xl p-10 transition-all duration-300 transform hover:scale-110 hover:shadow-2xl hover:shadow-amber-500/50 relative overflow-hidden"
            >
              <Scale className="w-16 h-16 text-amber-300 mx-auto mb-6 group-hover:scale-110 transition-transform duration-300" />
              <h3 className="text-2xl font-bold text-white mb-4">I'm a Lawyer</h3>
              <p className="text-emerald-200 mb-6">
                Manage your practice and connect with clients seeking legal services
              </p>
              <div className="flex items-center justify-center text-amber-300 group-hover:text-white transition-colors duration-300">
                <span className="mr-2">Get Started</span>
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
              </div>
              <div className="absolute inset-0 bg-gradient-to-br from-amber-400/10 to-orange-400/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RoleSelection;