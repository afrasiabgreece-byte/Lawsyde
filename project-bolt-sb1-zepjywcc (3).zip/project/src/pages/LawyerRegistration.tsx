import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { Scale, ArrowRight, User, Mail, Phone, MapPin, FileText, Award, Clock, Globe, CheckCircle, Brain, ArrowLeft } from 'lucide-react';
import ModernBackground from '../components/ModernBackground';

const LawyerRegistration: React.FC = () => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    specialty: '',
    experienceYears: '',
    education: '',
    barNumber: '',
    facebookProfile: '',
    password: '',
    confirmPassword: ''
  });
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const specialties = [
    'Immigration Law',
    'Corporate Law',
    'Immigration & Corporate Law',
    'Business Immigration',
    'Corporate Compliance',
    'International Business Law',
    'Visa & Permits',
    'Company Formation',
    'Other'
  ];

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async () => {
    if (formData.password !== formData.confirmPassword) {
      alert('Passwords do not match');
      return;
    }

    setLoading(true);
    try {
      // Create auth user
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.password,
        options: {
          data: { full_name: formData.fullName }
        }
      });

      if (authError) throw authError;

      if (authData.user) {
        // Create lawyer application
        const { error: applicationError } = await supabase.from('lawyer_applications').insert({
          user_id: authData.user.id,
          full_name: formData.fullName,
          email: formData.email,
          phone: formData.phone,
          specialty: formData.specialty,
          experience_years: parseInt(formData.experienceYears),
          education: formData.education,
          bar_number: formData.barNumber,
          facebook_profile: formData.facebookProfile,
          status: 'pending'
        });

        if (applicationError) throw applicationError;

        alert('🎉 Application submitted successfully! We will review your application and contact you within 24 hours.');
        navigate('/');
      }
    } catch (error: any) {
      alert('Error: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen text-white relative">
      <ModernBackground />
      
      {/* Header */}
      <nav className="relative z-20 flex items-center justify-between p-6">
        <div className="flex items-center">
          <button
            onClick={() => navigate('/')}
            className="mr-4 bg-white/10 backdrop-blur-lg hover:bg-white/20 text-white p-3 rounded-full transition-all duration-300 transform hover:scale-110 border border-white/30 hover:border-white/50 shadow-lg hover:shadow-white/30"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <Scale className="w-8 h-8 text-white mr-3" />
          <span className="text-2xl font-bold">Lawsyde</span>
          <span className="ml-2 text-xs bg-gradient-to-r from-green-400 to-blue-400 px-2 py-1 rounded-full text-black font-semibold animate-pulse">
            AI-POWERED
          </span>
        </div>
        <button
          onClick={() => navigate('/')}
          className="bg-gradient-to-r from-white/25 to-white/15 backdrop-blur-sm hover:from-white/35 hover:to-white/25 px-6 py-3 rounded-full font-bold transition-all duration-300 border-2 border-white/40 hover:border-white/60 shadow-lg hover:shadow-white/30 transform hover:scale-110"
        >
          Home
        </button>
      </nav>

      <div className="relative z-10 max-w-4xl mx-auto px-6 py-12">
        <div className="text-center mb-12">
          <div className="inline-flex items-center bg-gradient-to-r from-purple-500/20 to-blue-500/20 backdrop-blur-sm border border-purple-300/30 rounded-full px-8 py-4 mb-8">
            <Brain className="w-6 h-6 text-purple-300 mr-3 animate-pulse" />
            <span className="text-purple-200 font-bold text-lg">Join Our Professional Network</span>
          </div>
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Become a Lawsyde Lawyer
          </h1>
          <p className="text-xl text-blue-200 max-w-3xl mx-auto">
            Join Athens' premier AI-powered legal platform and connect with clients through multiple channels
          </p>
        </div>

        <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20">
          {/* Step Indicator */}
          <div className="flex items-center justify-center mb-8">
            <div className="flex items-center space-x-4">
              <div className={`flex items-center ${step >= 1 ? 'text-blue-400' : 'text-gray-400'}`}>
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${step >= 1 ? 'bg-blue-600 text-white' : 'bg-gray-600'}`}>
                  1
                </div>
                <span className="ml-2 font-medium">Personal Info</span>
              </div>
              <div className={`w-12 h-0.5 ${step >= 2 ? 'bg-blue-600' : 'bg-gray-600'}`}></div>
              <div className={`flex items-center ${step >= 2 ? 'text-blue-400' : 'text-gray-400'}`}>
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${step >= 2 ? 'bg-blue-600 text-white' : 'bg-gray-600'}`}>
                  2
                </div>
                <span className="ml-2 font-medium">Professional</span>
              </div>
              <div className={`w-12 h-0.5 ${step >= 3 ? 'bg-blue-600' : 'bg-gray-600'}`}></div>
              <div className={`flex items-center ${step >= 3 ? 'text-blue-400' : 'text-gray-400'}`}>
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${step >= 3 ? 'bg-blue-600 text-white' : 'bg-gray-600'}`}>
                  3
                </div>
                <span className="ml-2 font-medium">Account</span>
              </div>
            </div>
          </div>

          {/* Step 1: Personal Information */}
          {step === 1 && (
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-center mb-6">Personal Information</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-blue-200 mb-2">
                    <User className="w-4 h-4 inline mr-1" />
                    Full Name
                  </label>
                  <input
                    type="text"
                    value={formData.fullName}
                    onChange={(e) => handleInputChange('fullName', e.target.value)}
                    className="w-full p-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-blue-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Enter your full name"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-blue-200 mb-2">
                    <Mail className="w-4 h-4 inline mr-1" />
                    Email Address
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                    className="w-full p-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-blue-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="your.email@example.com"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-blue-200 mb-2">
                    <Phone className="w-4 h-4 inline mr-1" />
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => handleInputChange('phone', e.target.value)}
                    className="w-full p-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-blue-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="+30 123 456 7890"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-blue-200 mb-2">
                    <Globe className="w-4 h-4 inline mr-1" />
                    Facebook Profile (Optional)
                  </label>
                  <input
                    type="url"
                    value={formData.facebookProfile}
                    onChange={(e) => handleInputChange('facebookProfile', e.target.value)}
                    className="w-full p-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-blue-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="https://facebook.com/yourprofile"
                  />
                </div>
              </div>

              <div className="flex justify-end">
                <button
                  onClick={() => setStep(2)}
                  disabled={!formData.fullName || !formData.email || !formData.phone}
                  className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white px-10 py-4 rounded-xl font-bold text-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed shadow-xl hover:shadow-emerald-500/60 transform hover:scale-110 border-2 border-emerald-300/30 hover:border-emerald-200"
                >
                  Continue
                  <ArrowRight className="w-5 h-5 ml-2" />
                </button>
              </div>
            </div>
          )}

          {/* Step 2: Professional Information */}
          {step === 2 && (
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-center mb-6">Professional Information</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-blue-200 mb-2">
                    <Award className="w-4 h-4 inline mr-1" />
                    Legal Specialty
                  </label>
                  <select
                    value={formData.specialty}
                    onChange={(e) => handleInputChange('specialty', e.target.value)}
                    className="w-full p-3 bg-white/10 border border-white/20 rounded-lg text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">Select your specialty</option>
                    {specialties.map((specialty) => (
                      <option key={specialty} value={specialty} className="bg-gray-800">
                        {specialty}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-blue-200 mb-2">
                    <Clock className="w-4 h-4 inline mr-1" />
                    Years of Experience
                  </label>
                  <input
                    type="number"
                    value={formData.experienceYears}
                    onChange={(e) => handleInputChange('experienceYears', e.target.value)}
                    className="w-full p-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-blue-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="5"
                    min="0"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-blue-200 mb-2">
                    <FileText className="w-4 h-4 inline mr-1" />
                    Education & Qualifications
                  </label>
                  <textarea
                    value={formData.education}
                    onChange={(e) => handleInputChange('education', e.target.value)}
                    className="w-full p-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-blue-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                    rows={3}
                    placeholder="Law degree, certifications, university..."
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-blue-200 mb-2">
                    <Award className="w-4 h-4 inline mr-1" />
                    Bar Number (Optional)
                  </label>
                  <input
                    type="text"
                    value={formData.barNumber}
                    onChange={(e) => handleInputChange('barNumber', e.target.value)}
                    className="w-full p-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-blue-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Greek Bar Association Number"
                  />
                </div>
              </div>

              <div className="flex justify-between">
                <button
                  onClick={() => setStep(1)}
                  className="bg-gradient-to-r from-gray-600 to-gray-700 hover:from-gray-500 hover:to-gray-600 text-white px-8 py-3 rounded-xl font-bold transition-all duration-300 shadow-lg hover:shadow-gray-500/50 transform hover:scale-110 border-2 border-gray-400/30"
                >
                  Back
                </button>
                <button
                  onClick={() => setStep(3)}
                  disabled={!formData.specialty || !formData.experienceYears || !formData.education}
                  className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white px-10 py-4 rounded-xl font-bold text-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed shadow-xl hover:shadow-emerald-500/60 transform hover:scale-110 border-2 border-emerald-300/30 hover:border-emerald-200"
                >
                  Continue
                  <ArrowRight className="w-5 h-5 ml-2" />
                </button>
              </div>
            </div>
          )}

          {/* Step 3: Account Setup */}
          {step === 3 && (
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-center mb-6">Account Setup</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-blue-200 mb-2">
                    Password
                  </label>
                  <input
                    type="password"
                    value={formData.password}
                    onChange={(e) => handleInputChange('password', e.target.value)}
                    className="w-full p-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-blue-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Create a strong password"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-blue-200 mb-2">
                    Confirm Password
                  </label>
                  <input
                    type="password"
                    value={formData.confirmPassword}
                    onChange={(e) => handleInputChange('confirmPassword', e.target.value)}
                    className="w-full p-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-blue-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Confirm your password"
                  />
                </div>
              </div>

              {/* Application Summary */}
              <div className="bg-emerald-900/30 rounded-xl p-6 border border-emerald-400/30">
                <h4 className="text-lg font-bold text-emerald-200 mb-4 flex items-center">
                  <CheckCircle className="w-5 h-5 mr-2" />
                  Application Summary
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-emerald-300">Name:</span>
                    <span className="text-white ml-2">{formData.fullName}</span>
                  </div>
                  <div>
                    <span className="text-emerald-300">Email:</span>
                    <span className="text-white ml-2">{formData.email}</span>
                  </div>
                  <div>
                    <span className="text-emerald-300">Phone:</span>
                    <span className="text-white ml-2">{formData.phone}</span>
                  </div>
                  <div>
                    <span className="text-emerald-300">Specialty:</span>
                    <span className="text-white ml-2">{formData.specialty}</span>
                  </div>
                  <div>
                    <span className="text-emerald-300">Experience:</span>
                    <span className="text-white ml-2">{formData.experienceYears} years</span>
                  </div>
                </div>
              </div>

              <div className="bg-yellow-900/30 rounded-xl p-6 border border-yellow-400/30">
                <h4 className="text-lg font-bold text-amber-200 mb-2">Review Process</h4>
                <p className="text-amber-100 text-sm">
                  Your application will be reviewed within 24 hours. Once approved, you'll be able to connect with clients through calls, WhatsApp, Facebook, video calls, and on-site meetings.
                </p>
              </div>

              <div className="flex justify-between">
                <button
                  onClick={() => setStep(2)}
                  className="bg-gradient-to-r from-gray-600 to-gray-700 hover:from-gray-500 hover:to-gray-600 text-white px-8 py-3 rounded-xl font-bold transition-all duration-300 shadow-lg hover:shadow-gray-500/50 transform hover:scale-110 border-2 border-gray-400/30"
                >
                  Back
                </button>
                <button
                  onClick={handleSubmit}
                  disabled={loading || !formData.password || !formData.confirmPassword || formData.password !== formData.confirmPassword}
                  className="bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-white px-12 py-4 rounded-xl font-bold text-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center shadow-xl hover:shadow-emerald-500/60 transform hover:scale-110 border-2 border-emerald-300/30 hover:border-emerald-200 relative overflow-hidden"
                >
                  <span className="relative z-10 flex items-center">
                    {loading ? (
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                    ) : (
                      <CheckCircle className="w-5 h-5 mr-2" />
                    )}
                    {loading ? 'Submitting...' : 'Submit Application'}
                  </span>
                  <div className="absolute inset-0 bg-gradient-to-r from-emerald-400 to-teal-400 opacity-0 hover:opacity-30 transition-opacity duration-300"></div>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default LawyerRegistration;